-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 05:34 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_teacher_trainer`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(10) NOT NULL,
  `announcement` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `announcement`) VALUES
(12, 'We warmly welcome our New Batch of 2022 to Edeze Online Teacher Training School. We will be providing you a quality education through our online platform. Students can access the lecture links in the respective course page and your account.\r\n\r\nThankyou.\r\n(01/05/2022) '),
(13, 'This is to inform that All Examinations scheduled for 14/05/2022 has been postponed and rescheduled date will be advised later. Please refer Announcement page regularly for latest updates.\r\n\r\n(11/05/2022)'),
(14, 'The Eligibility list  for Final Examination (Year 1 Semester 1) starting on 20th May 2022 is published in the Account page.\r\nIf your name is not in the eligibility list, please fill the  form  in given link on or before 14/05/2022.\r\nIf your name is in this list and you have trouble in accessing the Exam Links please contact the  Examination Division: 0112544779 or 0112544778\r\n(11/05/2022)'),
(16, 'Year 1 Semester 2, Project Registration\r\n1. ONLY the Leader has to register their group by adding group member details.\r\n2. The Maximum number of members for a group is Five.\r\n3. The project groups can be formed ONLY within the same sub-group.\r\n4. You cannot create a group with other sub-groups as the evaluations are done on the lab time itself.\r\n5. If you have less than five members, you can register your group with the existing members, and we will allocate the remaining members later.\r\n6. The deadline for group registration is 18/05/2022 at 5.00 p.m.\r\n'),
(17, 'Edeze management has organized an Awareness session for Year 1 students on examinations with the support of the examination unit. The main goal is to discuss all the general information related to examinations. (IC and IC related issues)\r\n\r\nAll the students must go through the recording and understand all the steps before facing the mid examination.\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `St_id` int(11) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Age` int(10) NOT NULL,
  `NIC` varchar(12) NOT NULL,
  `Contact_num` int(15) NOT NULL,
  `Street_address` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Province` varchar(50) NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`St_id`, `Name`, `Age`, `NIC`, `Contact_num`, `Street_address`, `City`, `Province`, `Email`, `Password`) VALUES
(10, 'Saranga Dissanayake', 24, '199845676802', 716548394, '108/A, Samagi Mawatha', 'Matara', 'Southern Province', 'saranga@gmail.com', 'Saranga@123'),
(11, 'Timasha Perera', 22, '200065887623', 714887734, '102/6, Dixit Road, Maharagama', 'Colombo', 'Western Province', 'timasha123@gmail.com', 'Timasha@123'),
(12, 'Hansini Perera', 25, '19974563389V', 777456980, 'Temple Road, Kalalgoda', 'Colombo', 'Western Province', 'hansini@gmail.com', 'Hansini@123'),
(13, 'Chanuka Rathnaweera', 27, '19956782346V', 726500982, '109/9, Kate gardens', 'Matara', 'Western Province', 'chanuka123@gmail.com', 'Chanuka@123'),
(14, 'Arun Karthik', 23, '199967983456', 765579034, '205/C, Eksath Mawatha', 'Anuradhapura', 'North Central Province', 'arun@gmail.com', 'Arun@123'),
(15, 'Pasandi Sithpiyumi', 22, '200057669733', 776548870, '302/9, Battaramulla', 'Colo', 'Western Province', 'pasandi@gmail.com', 'Pasandi@123'),
(16, 'Kushini Sithara', 23, '199966547863', 725679829, '107/V, sumudu mawatha', 'Batticoloa', 'Eastern Province', 'kushini@gmail.com', 'Kushini@123'),
(17, 'Lahiru Darmaweera', 25, '199855768932', 725948372, '200/3, 1st lane, kiribathgoda', 'Colombo', 'Western Province', 'lahiru@gmail.com', 'Lahiru@123'),
(18, 'Thiwanka Abeysighe', 25, '199869504837', 715467896, '202/C, Green Valley Drive', 'Matara', 'Southern Province', 'thiwanaka@gmail.com', 'Thiwanka@123'),
(19, 'Sadeesha Dilki', 24, '19983345426V', 776545670, '302/6, Rose gardens', 'Badulla', 'Uva province', 'dilki@gmail.com', 'Dilki@123'),
(20, 'Piyumi Rathnayake', 22, '200067958472', 754865901, '103/A, Vidyakara Mawatha, Pannipitiya', 'Colombo', 'Western Province', 'piyumi@gmail.com', 'Piyumi@123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`St_id`),
  ADD UNIQUE KEY `NIC` (`NIC`),
  ADD UNIQUE KEY `Email` (`Email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `St_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
