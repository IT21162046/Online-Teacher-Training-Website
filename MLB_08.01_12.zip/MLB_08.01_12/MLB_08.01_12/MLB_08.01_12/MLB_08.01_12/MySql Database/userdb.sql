-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2022 at 06:54 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `userdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_name` varchar(200) NOT NULL,
  `admin_id` varchar(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_num` int(12) NOT NULL,
  `course` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_name`, `admin_id`, `email`, `contact_num`, `course`, `gender`, `district`) VALUES
('Mr P.A.Perera', 'AD071', 'perera@gmail.com', 725687942, 'Pre-School Teaching', 'Male', 'Gampaha'),
('MRs P.P.Shanika', 'AD072', 'shanika@gmail.com', 722876425, 'Special-Needs Teaching', 'Female', 'Bandarawela');

-- --------------------------------------------------------

--
-- Table structure for table `course_coordinator`
--

CREATE TABLE `course_coordinator` (
  `cc_name` varchar(200) NOT NULL,
  `cc_id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_num` int(12) NOT NULL,
  `course` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_coordinator`
--

INSERT INTO `course_coordinator` (`cc_name`, `cc_id`, `email`, `contact_num`, `course`, `gender`, `district`) VALUES
('Mr N.W.Liyanage', 'CC010', 'liyanage@gmail.com', 765162789, 'Secondary Teaching Course', 'Male', 'Kaluthara'),
('Mr P.B.Silva', 'CC011', 'silva@gmail.com', 712458299, 'Primary Teaching Course', 'Male', 'Colombo');

-- --------------------------------------------------------

--
-- Table structure for table `lecturer`
--

CREATE TABLE `lecturer` (
  `lec_name` varchar(200) NOT NULL,
  `lec_id` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_num` int(12) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer`
--

INSERT INTO `lecturer` (`lec_name`, `lec_id`, `email`, `contact_num`, `subject`, `gender`, `district`) VALUES
('Ms P.P.Thiruni', 'LC504', 'thiruni@gmail.com', 768324075, 'English Language', 'Female', 'Colombo'),
('Mr R.M.Kuruppu', 'LC505', 'kuruppu@gmail.com', 768576339, 'Sinhala Language', 'Male', 'Rathnapura');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `st_name` varchar(200) NOT NULL,
  `st_id` varchar(5) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_num` int(12) NOT NULL,
  `course` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `district` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`st_name`, `st_id`, `email`, `contact_num`, `course`, `gender`, `district`) VALUES
('Ms P.N.Rathnayaka', 'En211', 'rathnayake@gmail.com', 754218560, 'Primary Teaching Course', 'Female', 'Colombo'),
('Mr C.D.Rathnaweera', 'EN212', 'rathnaweera@gmail.com', 778245575, 'Secondary Teaching Course', 'Male', 'Kandy');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `course_coordinator`
--
ALTER TABLE `course_coordinator`
  ADD PRIMARY KEY (`cc_id`);

--
-- Indexes for table `lecturer`
--
ALTER TABLE `lecturer`
  ADD PRIMARY KEY (`lec_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`st_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
