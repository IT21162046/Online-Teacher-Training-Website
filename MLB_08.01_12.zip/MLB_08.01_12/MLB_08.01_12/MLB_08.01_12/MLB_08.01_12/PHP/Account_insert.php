<?php require_once('connection.php'); ?>
<?php
	
	$admin_name = 'Mr.S.S.Dhananjaya';
	$admin_id = 'AD073';
	$email = 'dhananjaya@gmail.com';
	$contact_num = '0722589322';
	$course = 'Music Teaching Course';
	$gender = 'Male';
	$district = 'Bandarawela';
	
	$query = "INSERT INTO admin(admin_name, admin_id, email, contact_num, course, gender, district) VALUES('{$admin_name}', '{$admin_id}', '{$email}', '{$contact_num}', '{$course}', '{$gender}', '{$district}')";
	
	$result = mysqli_query($connection, $query);
	
	if ($result) {
		echo "1 Record aded";
	} else {
		echo "Database query failed.";
	}
	
	$cc_name = 'Mr.D.H.Rajapaksha';
	$cc_id = 'CC014';
	$email = 'rajapaksha@gmail.com';
	$contact_num = '0752486970';
	$course = 'Special Needs Teaching Course';
	$gender = 'Male';
	$district = 'Galle';
	
	$query = "INSERT INTO course_coordinator(cc_name, cc_id, email, contact_num, course, gender, district) VALUES('{$cc_name}', '{$cc_id}', '{$email}', '{$contact_num}', '{$course}', '{$gender}', '{$district}')";
	
	$result = mysqli_query($connection, $query);
	
	if ($result) {
		echo "1 Record aded";
	} else {
		echo "Database query failed.";
	}
	
	$lec_name = 'Mrs.A.D.Athukorala';
	$lec_id = 'LC508';
	$email = 'athukorala@gmail.com';
	$contact_num = '0763825684';
	$subject = 'Science for Secondary Students';
	$gender = 'Female';
	$district = 'Mathale';
	
	$query = "INSERT INTO lecturer(lec_name, lec_id, email, contact_num, subject, gender, district) VALUES('{$lec_name}', '{$lec_id}', '{$email}', '{$contact_num}', '{$subject}', '{$gender}', '{$district}')";
	
	$result = mysqli_query($connection, $query);
	
	if ($result) {
		echo "1 Record aded";
	} else {
		echo "Database query failed.";
	}
	
	$st_name = 'Ms.R.R.Ubeysinghe';
	$st_id = 'EN215';
	$email = 'ubeysinghe@gmail.com';
	$contact_num = '0778954179';
	$course = 'Music Teaching Course';
	$gender = 'Female';
	$district = 'Kandy';
	
	$query = "INSERT INTO student(st_name, st_id, email, contact_num, course, gender, district) VALUES('{$st_name}', '{$st_id}', '{$email}', '{$contact_num}', '{$course}', '{$gender}', '{$district}')";
	
	$result = mysqli_query($connection, $query);
	
	
	if ($result) {
		echo "1 Record aded";
	} else {
		echo "Database query failed.";
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Insert Query</title>
</head>
<body>
</body>
</html>
<?php mysqli_close($connection); ?>