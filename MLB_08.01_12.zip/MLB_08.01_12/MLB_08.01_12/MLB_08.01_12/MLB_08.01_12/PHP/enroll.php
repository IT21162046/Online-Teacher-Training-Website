<html>
<head>

	<title>Enroll</title>

	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet"  href="../css/enroll.css">
	
	<script src="../js/payment.js" >  </script>

</head>
<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
		<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			<li><a href="home_page.php">Home</a></li>
			<li><a href="Courses.php">Courses</a></li>
			<li><a href="Download.php">Download</a></li>
			<li><a href="announcement.php">Announcements</a></li>	
			<li><a class="active" href="enroll.php">Enroll</a></li>
			<li><a href="feedback.php">Feedbacks</a></li>
			<li><a href="Account.php">Account</a></li>
			<li><a href="staffPage.php">Staff</a></li>
			<li><a href="loginPage.php">Log in</a></li>
			<li><a href="register.php">Register now</a></li>
		</ul>
	</div>

	
	<!-- end of the header --> 
      
     <img src="../images/Courses/e1.jpg" alt="noo" width="100%" height="250px">
	 <div class="style">
	 
	 <div class="container">
       <div class="left">
	   <h3>Student Details </h3>
	   
	   <form name="enroll" method="post" action=" ">
	     Username <input type="text" name="user" id="user" placeholder="Enter username">
	     Full name<input type="text" name="name" id="name" placeholder="Enter name">
		 Email<input type="email" name="email" id="email" placeholder="Enter email">
		 Contact number <input type="phone" name="number" id="number" placeholder="+94**********">
		 Course name <input type="text" name="course" id="course" placeholder="Enter course">
		 
		 
		  
		
		 <h3> Payment Details</h3>
		  <img src="../images/Courses/pay.png" alt="noo" width="220px">
		  Credit Card Number  <input type="text" id="cardno" placeholder="Enter card number" required>
		 Exp Month  <input type="text" id="cardno" placeholder="Enter card month" maxlength="2">
		  <div id="zip">
		  <label>
		    Exp year<select>
			   <option>choose year..</option>
			   <option>2023</option>
			   <option>2024</option>
			   <option>2025</option>
			   <option>2026</option>
			</select>
		  </label>
		     <label>
			    CVV<input type="text" id="month" placeholder=" cvv" maxlength="3">
	      </label> </br>
		  </div>
		  </form>
		    <input type="checkbox" id="checkbox" class="inputStyle" onclick="enableButton()" >Accept Terms and Conditions </br>
		    <input type="submit" name="submit"  id="submitBtn" value="proceed to checkout" disabled>
			 
		</div>	
	</div>
	</div>
	
  
	
	<!-- Footer -->
	
	<div class="coldiv">

				
		<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
			<table class="font">
				<tr style="font-size: larger; color: #2e7d4d;">
					<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
					<th style="width: 30%;">Useful Links</th>
					<th style="width: 30%;">Our Social Networks</th>
				</tr>

				<tr>
					<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
				

					
					<td style="padding-left: 170px;" >
						<a href="home_page.php" class="link">Home</a><br>
						<a href="Courses.php" class="link">Courses</a><br>
						<a href="Download.php" class="link"> Download</a><br>
						<a href="announcement.php" class="link"> Announcements</a><br>
						<a href="enroll.php" class="link">Enroll</a><br>
						<a href="feedback.php" class="link">Feedbacks</a><br>
						<a href="Account.php" class="link">Account</a><br>
						<a href="staffPage.php" class="link">Staff</a><br>
						<a href="loginPage.php" class="link">Log in</a><br>
						<a href="register.php" class="link">Register</a>
					</td>

					<td style="padding-left: 110px; padding-top: 20px;">
						<div class="SocialLogos">
							<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
							<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
							<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
							<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 -edeze - Online Teacher Training School - All Right Reserved</h3></center>
	</div>


	<!-- End of the Footer  -->
	
</body>

</html>