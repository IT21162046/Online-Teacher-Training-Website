<!DOCTYPE html>
<html lang="en">
<head><title>Feedbacks</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link href="https://fonts.googleapis.com/css?family=Barlow+Semi+Condensed" rel="stylesheet">
	<meta charset="UTF-8">
	  <link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="../css/feedback.css">
</head>
<body>
	<!-- Header --> 

		<div style="margin-left: 7px; margin-right: 7px">

			<center>
			<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 15px; padding-bottom: 10px;">

			</center>
			
			<!-- Navigation Bar --> 
				<ul style="font-family: Arial, Helvetica, sans-serif;">
					
					<li><a href="home page.php">Home</a></li>
					<li><a href="Courses.php">Courses</a></li>
					<li><a href="Download.php">Download</a></li>
					<li><a href="announcement.php">Announcements</a></li>	
					<li><a href="enroll.php">Enroll</a></li>
					<li><a class="active" href="feedback.php">Feedbacks</a></li>
					<li><a href="Account.php">Account</a></li>
					<li><a href="staffPage.php">Staff</a></li>
					<li><a href="login.php">Log in</a></li>
					<li><a href="register.php" >Register now</a></li>
				</ul>
		</div>

	<!-- end of the header --> 
		
	<div class="main-section">
		<table style="padding-top:0px">
			<tr>
				<td style="padding-left:75px; padding-right:55px">
					<h1 style="font-size:60px; color:#3d8f5d">Feedbacks</h1><br><br>
					<h2>Feel free to drop us a line and give us your<br> feedback</h2><br>
					<h3>We are looking forward to hearing back from you.</h3>
					<br>
					<div class="rate">
						<input type="radio" id="star5" name="rate" value="5" />
						<label for="star5" title="text">5 stars</label>
						<input type="radio" id="star4" name="rate" value="4" />
						<label for="star4" title="text">4 stars</label>
						<input type="radio" id="star3" name="rate" value="3" />
						<label for="star3" title="text">3 stars</label>
						<input type="radio" id="star2" name="rate" value="2" />
						<label for="star2" title="text">2 stars</label>
						<input type="radio" id="star1" name="rate" value="1" />
						<label for="star1" title="text">1 star</label>
					</div>
					<br><br><br><br><br>
					<form action="/action_page.php" method="post">
					  <input type="radio" id="Questions" name="feild" value="Questions">
					  <label for="Questions">Questions</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					  <input type="radio" id="Website" name="feild" value="Website">
					  <label for="Website">Website</label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					  <input type="radio" id="Courses" name="feild" value="Courses">
					  <label for="Courses">Courses</label><br>
					  <input type="radio" id="Suggestions" name="feild" value="Suggestions">
					  <label for="Suggestions">Suggestions</label>&nbsp&nbsp&nbsp
					  <input type="radio" id="Complements" name="feild" value="Complements">
					  <label for="Complements">Complements</label>&nbsp&nbsp&nbsp 
					  <input type="radio" id="Others" name="feild" value="Others">
					  <label for="Others">Others</label>
					</form>
				</td>
				<td>
				<form name="myForm"  method="POST" onsubmit="return validateForm()" style="padding-top:93px">

					Name: <br>
					<input type="text" name="realname" placeholder="First Name"> &nbsp&nbsp&nbsp <input type="text" name="realname" placeholder="Last Name"><br>
					<br>

					E-mail: <br>
					<input type="text" name="email" placeholder="Ex:Myname@example.com"><br>
					<br>

					Describe your feedback: <br>
					<textarea name="comments" rows="10" cols="50"></textarea><br><br>
				
					<input type="submit" value="Send" style="cursor: pointer"></div><br><br><br><br><br><br>
				 
				</form>
				</td>
			</tr>
		</table>

		<div class="rating-part">
		<div class="average-rating">
			<h2>4.5</h2>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i class="fa fa-star-half-o" aria-hidden="true"></i>
			<p>Average Rating</p>
		</div>
		<div class="loder-ratimg">
			<div class="progress"></div>
			<div class="progress-2"></div>
			<div class="progress-3"></div>
			<div class="progress-4"></div>
			<div class="progress-5"></div>
		</div>
		<div class="start-part">
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<span>80%</span><br>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<span>60%</span><br>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<span>40%</span><br>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<span>20%</span><br>
			<i aria-hidden="true" class="fa fa-star"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<i aria-hidden="true" class="fa fa-star-o"></i>
			<span>10%</span>
		</div>
		<div style="clear: both;"></div><br><br>
		<div class="reviews"><h1>User Reviews</h1></div>
		<div class="comment-part">
			<div class="user-img-part">
				<div class="user-img">
					<img src="../images/st1.jpg">
				</div>
				<div class="user-text">
					<h4>8 days ago</h4>
					<p>N.R.Wijethunge</p>
					<span>Student</span>
				</div>
				<div style="clear: both;"></div>
			</div>
			<div class="comment">
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star-o"></i>
				<p>The Teaching Course was very valuable to me as well as I'm sure it was valuable to others too.<br> 
				Edeze Taining College is a great educational center which is conducted through online platform<br> without any difficulty and interestingly.</p><br>
			</div>
			<div style="clear: both;"></div>
		</div>
		<div class="comment-part">
			<div class="user-img-part">
				<div class="user-img">
					<img src="../images/st2.png">
				</div>
				<div class="user-text">
					<h4>30 days ago</h4>
					<p>K. Dharshana</p>
					<span>Student</span>
				</div>
				<div style="clear: both;"></div>
			</div>
			<div class="comment">
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i class="fa fa-star-half-o" aria-hidden="true""></i>
				<i aria-hidden="true" class="fa fa-star-o"></i>
				<p>
				I was not sure about my future when I first join Edeze. But after 3 years, Edeze made me a teacher<br> with so much of motivation and courage with determination. 
				Today I'm a teacher at xx school. Though<br> it is conducted online, it is really worthful and they conduct the lectures very interestingly and friendly manner. 
				This saves time also and we had plenty to study for exams. I highly recommend Edeze<br> Online Teacher Training School for everyone who wish to become a teacher.
				</p><br>
			</div>
			<div style="clear: both;"></div>
		</div>
		<div class="comment-part">
			<div class="user-img-part">
				<div class="user-img">
					<img src="../images/st3.jpg">
				</div>
				<div class="user-text">
					<h4>1 days ago</h4>
					<p>R.M.Kuruppu</p>
					<span>Student</span>
				</div>
				<div style="clear: both;"></div>
			</div>
			<div class="comment">
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star-o"></i>
				<p>I highly recommend Edeze Teaching School. It gave me opportunty to become a successful teacher.<br> 
				It was very easy for me to join as a teacher to reputed international school in Sri Lanka since Edeze<br> is approved by Teritary and Vocational Commision of Sri Lanka.</p><br>
			</div>
			<div style="clear: both;"></div>
		</div>
		<div class="comment-part">
			<div class="user-img-part">
				<div class="user-img">
					<img src="../images/lec1.jpg">
				</div>
				<div class="user-text">
					<h4>24 days ago</h4>
					<p>Nick Greck</p>
					<span>Lecturer</span>
				</div>
				<div style="clear: both;"></div>
			</div>
			<div class="comment">
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i aria-hidden="true" class="fa fa-star"></i>
				<i class="fa fa-star-half-o" aria-hidden="true"></i>
				<p>I am very happy to be a lecturer at edeze Online Teacher Training School. 
				Due to the good management and organization of this institution, I have been able to give lectures easily without any difficulty.</p>
			</div>
			<div style="clear: both; padding-bottom:84px"></div>
		</div>
		</div>
	</div>
	
	<script>
	
		function validateForm() {
		  let x = document.forms["myForm"]["realname"].value;
		  if (x == "") {
			alert("Name must be filled out");
			return false;
		  }
		}
		
		function validateForm() {
		  let x = document.forms["myForm"]["email"].value;
		  if (x == "") {
			alert("Email must be filled out");
			return false;
		  }
		}
		
		function validateForm() {
		  let x = document.forms["myForm"]["comments"].value;
		  if (x == "") {
			alert("Feedback must be filled out");
			return false;
		  }
		}
	</script>

	<!-- Footer -->
		
		<div class="coldiv" style="margin-left: 7px; margin-right: 7px; margin-bottom:20px">

					
					<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
						<center>
						<table class="font">
							<tr style="font-size: larger; color: #2e7d4d;">
								<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
								<th style="width: 30%;">Useful Links</th>
								<th style="width: 30%;">Our Social Networks</th>
							</tr>

							<tr>
								<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
							

								
								<td style="padding-left: 170px;" >
									<a href="home page.php" class="link">Home</a><br>
									<a href="Courses.php" class="link">Courses</a><br>
									<a href="Download.php" class="link"> Download</a><br>
									<a href="announcement.php" class="link"> Announcements</a><br>
									<a href="enroll.php" class="link">Enroll</a><br>
									<a href="feedback.php" class="link">Feedbacks</a><br>
									<a href="Account.php" class="link">Account</a><br>
									<a href="staffPage.php" class="link">Staff</a><br>
									<a href="login.php" class="link">Log in</a><br>
									<a href="register.php" class="link">Register</a>
								</td>

								<td style="padding-left: 110px; padding-top: 20px;">
									<div class="SocialLogos">
										<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
										<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
										<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
										<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
										 
									</div>
								</td>


							</tr>

						</table>
						</center>
					
					</div>
						<center><h3 style="padding-top: 31px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 - edeze - Online Teacher Training School - All Right Reserved</h3></center>
				</div>

	<!-- End of the Footer  -->
	
</body>
</html>