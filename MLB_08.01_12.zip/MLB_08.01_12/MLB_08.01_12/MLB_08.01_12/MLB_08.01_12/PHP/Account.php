<?php 
	
	require_once('connection.php');
	
	$sql = "SELECT * FROM lecturer WHERE lec_id = 'LC504'";

	$result = $connection->query($sql);


?>
<!DOCTYPE html>
<html>
<head>
	<title>User Account</title>
	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="../css/Account.css">
	

</head>
<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
			<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			  	<li><a href="home_page.php">Home</a></li>
			  	<li><a href="Courses.php">Courses</a></li>
			  	<li><a href="Download.php">Download</a></li>
			  	<li><a href="announcement.php">Announcements</a></li>	
			  	<li><a href="enroll.php">Enroll</a></li>
			  	<li><a href="feedback.php">Feedbacks</a></li>
			  	<li><a class="active" href="Account.php">Account</a></li>
			  	<li><a href="staffPage.php">Staff</a></li>
			  	<li><a href="login.php">Log in</a></li>
			  	<li><a href="register.php" >Register now</a></li>
			</ul>
	</div>

	<!-- end of the header --> 

	<center>
	<div class="rcorners">
		<div style="max-width:1200px; background-color: #f5f2f0; padding-bottom: 30px; margin-top: 80px; margin-bottom: 80px; border-radius: 25px">
			<table class = "tuser">
			<?php

            if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {

			?>
				<tr>
					<td style = "padding-left: 15px; padding-top: 50px">
						<table>
							<tr>
								<td>
									<img class="lecture" src="../images/lecturer.png">
									<h1><center><?php echo $row['lec_name']; ?></center></h1>
									<h3><center>Lecturer</center></h3>
								</td>
							</tr>
						</table>
					</td>

					<td style="padding-left: 135px">
						<table>
							<tr>
								<td>
									<br>
									<h1 style="padding-top: 20px"><center>User Details</center></h1><br>
							        <h3>User Id: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['lec_id']; ?></h3><hr>
									<h3>Email: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['email']; ?></h3><hr>
									<h3>Phone: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['contact_num']; ?></h3><hr>
									<h3>Subject: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['subject']; ?></h3><hr>
									<h3>Gender: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['gender']; ?></h3><hr>
									<h3 style="padding-bottom: 20px">District: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp <?php echo $row['district']; ?></h3>
								</td>
							</tr>
						</table>
					</td>

					<td style="padding-left: 120px">
						<table>
							<tr>
								<td>
									<br>
									<h3><img src="../images/setting.png" width="30" height="30" style="padding-right: 5px; padding-bottom: -5px">&nbsp Settings &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp 
										<div class="dropdown">
										  <button onclick="myFunction1()" class="dropbtn"> <h2>&rsaquo;</h2> </button>
										  <div id="myDropdown1" class="dropdown-content">
											<a href="password.php" class="link">Change password</a><hr>
											<a href="editprofile.php" class="link">Edit profile</a>
										  </div>
										</div> </a></h3>
									<h3><img src="../images/logout.png" width="30" height="30" style="padding-right: 5px"><a href="home_page.php" class="link">&nbsp Logout &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &rsaquo; </a></h3>
									<h3><img src="../images/notiication.png" width="30" height="30" style="padding-right: 5px"><a href="" class="link">&nbsp Notification &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &rsaquo; </a></h3>
									<h3><img src="../images/help.jpg" width="25" height="25" style="padding-right: 5px"><a href="" class="link">&nbsp Help & Support &nbsp&nbsp&nbsp&nbsp &rsaquo; </a></h3>
									<h3><img src="../images/feedback.png" width="30" height="30" style="padding-right: 5px"><a href="feedback.php" class="link">&nbsp Feedback &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &rsaquo; </a></h3>
								</td>
							</tr>
						</table>
					</td>
				</tr>
				<?php       
					}

					}

				?>
			</table>
			<br>
			<hr style="height:2px; color:green; background-color:green; margin-left:75px; margin-right:75px">
			<br>
			<h2 style="padding-bottom: 77px; padding-left: 80px; text-align: left">Course details <br><br><br> <p style="font-size:18px; font-family: calibry">Primary Teaching Course<br><br>Secondary Teaching Course<br><br>Pre-School Teaching Course<br><br>Special Needs Teaching Course<br><br>Music Teaching Course</p></h2>
			<br>
			<hr style="height:2px; color:green; background-color:green; margin-left:75px; margin-right:75px">
			<br>
			<h2 style="padding-bottom: 143px; padding-left: 75px; text-align: left">Login activity<br><br><br>
			<p style="font-size:18px; font-family: calibry">First access to site<br>&nbsp&nbsp&nbsp&nbsp  Monday, 7 June 2021, 2:50 PM<br><br>
            Last access to site<br>&nbsp&nbsp&nbsp&nbsp  Thursday, 12 May 2022, 10:33 AM</p></h2>
			<br>
		</div>
	</div>
	</center>
	
	<script>
	function myFunction1() {
	document.getElementById("myDropdown1").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	</script>
	
<!-- Footer -->
	
	<div class="coldiv">

				
				<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
					<center>
					<table class="font">
						<tr style="font-size: larger; color: #2e7d4d;">
							<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
							<th style="width: 30%;">Useful Links</th>
							<th style="width: 30%;">Our Social Networks</th>
						</tr>

						<tr>
							<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
						

							
							<td style="padding-left: 170px;" >
								<a href="home page.php" class="link">Home</a><br>
								<a href="Courses.php" class="link">Courses</a><br>
								<a href="Download.php" class="link"> Download</a><br>
								<a href="announcement.php" class="link"> Announcements</a><br>
								<a href="enroll.php" class="link">Enroll</a><br>
								<a href="feedback.php" class="link">Feedbacks</a><br>
								<a href="Account.php" class="link">Account</a><br>
								<a href="staffPage.php" class="link">Staff</a><br>
								<a href="login.php" class="link">Log in</a><br>
								<a href="register.php" class="link">Register</a>
							</td>

							<td style="padding-left: 110px; padding-top: 20px;">
								<div class="SocialLogos">
									<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
									<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
									<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
									<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
									 
								</div>
							</td>


						</tr>

					</table>
					</center>
				
				</div>
					<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 - edeze - Online Teacher Training School - All Right Reserved</h3></center>
			</div>

	<!-- End of the Footer  -->

</body>
</html>
<?php mysqli_close($connection); ?>