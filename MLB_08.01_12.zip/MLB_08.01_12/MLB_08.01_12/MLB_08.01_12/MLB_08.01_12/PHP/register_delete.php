<?php 

include "register_config.php"; 

if (isset($_GET['id'])) {
    $st_id = $_GET['id'];
    $sql = " DELETE FROM student WHERE St_id='$st_id' ";
    $result = $conn->query($sql);

     if ($result == TRUE) {
        echo "Record deleted successfully.";
        header('Location: register_view.php');

    }else{
        echo "Error:" . $sql . "<br>" . $conn->error;
    }
} 

?>