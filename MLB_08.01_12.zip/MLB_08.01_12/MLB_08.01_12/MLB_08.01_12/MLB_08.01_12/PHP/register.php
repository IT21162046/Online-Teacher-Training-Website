
<html>
<head>

	<title>Register Form | Edeze</title>

	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="../css/register.css">

	<script src="../js/register.js"></script>
	

</head>

<body onload='document.registration.age.focus()'>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
		<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			<li><a href="home_page.php">Home</a></li>
			<li><a href="Courses.php">Courses</a></li>
			<li><a href="Download.php">Download</a></li>
			<li><a href="announcement.php">Announcements</a></li>	
			<li><a href="enroll.php">Enroll</a></li>
			<li><a href="feedback.php">Feedbacks</a></li>
			<li><a href="Account.php">Account</a></li>
			<li><a href="staffPage.php">Staff</a></li>
			<li><a href="loginPage.php">Log in</a></li>
			<li><a class="active" href="register.php">Register now</a></li>
		</ul>
	</div>

	<!-- end of the header --> 
	<br>

	<!-- form -->
	
		<center>
		<div style="padding-top: 20px; padding-bottom: 20px; width: 60%;" class="font">

			<form name='registration' method="POST" onsubmit="return formValidation();" style="padding-top: 40px; padding-bottom: 40px; border:2px solid black; padding-left: 30px; background-color: #f5f2f0;" action="reg_insert.php">  

				
				<center><h1>Student Registration From</h1></center>
				<hr style="width: 80%;"><br><br>

					<center>
					<img src="../images/register/pr.png" style="width: 20%;"><br><br><br>

					<lable for="username"> Enter the full name:</label><br>
					<input type="text" id="username" name="username" placeholder="Full Name" style="width: 50%;" required> <br><br>

					<lable for="age"> Enter your age:</label><br>
					<input type="text" id="age" name="age" placeholder="Age" style="width: 50%;" required> <br><br><br>


					<lable for="idnumber">Enter your ID number:</label><br>
					<input type="text" id="NIC" name="NIC" placeholder="ID Number" maxlength=12 style="width: 50%;" required> 
					<span id="message1"></span> <br><br>

					<lable for="contact">Enter the contact number:</label><br>
					<input type="text" id="contact" name="contact" placeholder="Contact Number" style="width: 50%"; required><br><br>
					
					<lable for="address"> Enter your address:</label><br>
					<input type="text" id="address" name="street" placeholder="Street Address" style="width: 50%;"><br>
					<input type="text" id="address" name="city" placeholder="City" style="width: 50%;"><br>
					<input type="text" id="address" name="province" placeholder="Province" style="width: 50%;"><br><br>

					<lable for="email">Enter your Email:</label><br>
					<input type="email" id="email" name="email" placeholder="Email Address" style="width: 50%;" required><br><br>

					<lable for="pwd">Enter a password:</label><br>
					<input type="password" id="pwd" name="passid" onkeyup="validatePassword(this.value);" placeholder="Password" size="12" style="width: 50%;" required><span id="msg"></span>
					<br><br>


					<center><p class="text1" id="a">By submitting this you agree to our <a href="t&C" >Terms and Conditions</a></p>

					<button type="submit" id="submit" name="submit" class="button" value="Submit"  style="height: 30px; width: 80px; background-color: #3d8f5d; border-color: #2e7d4d;" onclick="allnumeric(document.registration.age)" /><b>Submit</b></button></center>

					

				</center>
						
		</div>
	</center>
	

	<br>
	<!-- 	End of the form -->



	<!-- Footer -->
	
	<div class="coldiv">

				
		<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
			<table class="font">
				<tr style="font-size: larger; color: #2e7d4d;">
					<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
					<th style="width: 30%;">Useful Links</th>
					<th style="width: 30%;">Our Social Networks</th>
				</tr>

				<tr>
					<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
				

					
					<td style="padding-left: 170px;" >
						<a href="home_page.php" class="link">Home</a><br>
						<a href="Courses.php" class="link">Courses</a><br>
						<a href="Download.php" class="link"> Download</a><br>
						<a href="announcement.php" class="link"> Announcements</a><br>
						<a href="enroll.php" class="link">Enroll</a><br>
						<a href="feedback.php" class="link">Feedbacks</a><br>
						<a href="Account.php" class="link">Account</a><br>
						<a href="staffPage.php" class="link">Staff</a><br>
						<a href="loginPage.php" class="link">Log in</a><br>
						<a href="register.php" class="link">Register</a>
					</td>

					<td style="padding-left: 110px; padding-top: 20px;">
						<div class="SocialLogos">
							<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
							<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
							<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
							<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 -edeze - Online Teacher Training School - All Right Reserved</h3></center>
	</div>

	<!-- End of the Footer  -->
	
</body>

</html>