<?php require_once('connection.php'); 

	if(isset($_POST['submit'])){
		$admin_id=$_POST['admin_id'];
		$admin_name=$_POST['admin_name'];
		$email=$_POST['email'];
		$contact_num=$_POST['contact_num'];
		$course=$_POST['course'];
		$gender=$_POST['gender'];
		$district=$_POST['district'];
		
		$sql="insert into admin (admin_id,admin_name,email,contact_num,course,gender,district)
		values('$admin_id','$admin_name','$email','$contact_num','$course','$gender','$district')";
		$result=mysqli_query($connection,$sql);
		if($result){
			echo "Data inserted successfully";
		}else{
			die('Database connection failed' . mysqli_connect_error());
		}	
	}



?>
<!doctype html>
<html lang="en">
 <head>
  
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Add user details</title>
 </head>
 <body>
	<div class="container my-5">
	<form method="post">
	  <div class="form-group">
		<label>User Id</label>
		<input type="text" class="form-control" placeholder="Enter user id" name="admin_id">
	  </div>
	  <div class="form-group">
		<label>Name</label>
		<input type="text" class="form-control" placeholder="Enter name" name="admin_name">
	  </div>
	  <div class="form-group">
		<label>Email</label>
		<input type="email" class="form-control" placeholder="Enter email" name="email">
	  </div>
	  <div class="form-group">
		<label>Phone</label>
		<input type="tel" class="form-control" placeholder="Enter contact number" name="contact_num">
	  </div>
	  <div class="form-group">
		<label>Course/Subject</label>
		<input type="text" class="form-control" placeholder="Enter subject/course name" name="course">
	  </div>
	  <div class="form-group">
		<label>Gender</label>
		<input type="text" class="form-control" placeholder="Enter gender" name="gender">
	  </div>
	  <div class="form-group">
		<label>District</label>
		<input type="text" class="form-control" placeholder="Enter district" name="district">
	  </div>
	  
	  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
	</form>
	
	</div>

 </body>
</html>
<?php mysqli_close($connection); ?>