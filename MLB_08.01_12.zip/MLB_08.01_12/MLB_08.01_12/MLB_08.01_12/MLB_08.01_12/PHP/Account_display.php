<?php require_once('connection.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Display user details</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
	<div class = "containert">
		<button class="btn btn-primary my-5"><a href="Account_addUserA.php" class="text-light">add user</a>
		</button>
		<table class="table">
		  <thead>
			<tr>
			  <th scope="col">User ID</th>
			  <th scope="col">Name</th>
			  <th scope="col">Email</th>
			  <th scope="col">Phone</th>
			  <th scope="col">Subject/Course</th>
			  <th scope="col">Gender</th>
			  <th scope="col">District</th>
			  <th scope="col">Operations</th>
			</tr>
		  </thead>
		  <tbody>
		  
		  
		  
		  
		  <?php
			
			$sql="Select * from admin";
			$result=mysqli_query($connection, $sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
					$admin_id=$row['admin_id'];
					$admin_name=$row['admin_name'];
					$email=$row['email'];
					$contact_num=$row['contact_num'];
					$course=$row['course'];
					$gender=$row['gender'];
					$district=$row['district'];
					echo'<tr>
					  <th scope="row">'.$admin_id.'</th>
					  <td>'.$admin_name.'</td>
					  <td>'.$email.'</td>
					  <td>'.$contact_num.'</td>
					  <td>'.$course.'</td>
					  <td>'.$gender.'</td>
					  <td>'.$district.'</td>
					  <td>
						  <button class="btn btn-primary"><a href="Account_updateA.php?updateid='.$admin_id.'" class="text-light">Update</a></button>
						  <button class="btn btn-danger"><a href="Account_delete.php?deleteid='.$admin_id.'" class="text-light">Delete</a></button>
					  </td>
					</tr>';
				}
			}
		  
		  ?>
		  </tbody>
		</table>
		
		<button class="btn btn-primary my-5"><a href="Account_addUserC.php" class="text-light">add user</a>
		</button>
		<table class="table">
		  <thead>
			<tr>
			  <th scope="col">User ID</th>
			  <th scope="col">Name</th>
			  <th scope="col">Email</th>
			  <th scope="col">Phone</th>
			  <th scope="col">Subject/Course</th>
			  <th scope="col">Gender</th>
			  <th scope="col">District</th>
			  <th scope="col">Operations</th>
			</tr>
		  </thead>
		  <tbody>
		  
		  
		  
		  
		  <?php
			
			$sql="Select * from Course_coordinator";
			$result=mysqli_query($connection, $sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
					$cc_id=$row['cc_id'];
					$cc_name=$row['cc_name'];
					$email=$row['email'];
					$contact_num=$row['contact_num'];
					$course=$row['course'];
					$gender=$row['gender'];
					$district=$row['district'];
					echo'<tr>
					  <th scope="row">'.$cc_id.'</th>
					  <td>'.$cc_name.'</td>
					  <td>'.$email.'</td>
					  <td>'.$contact_num.'</td>
					  <td>'.$course.'</td>
					  <td>'.$gender.'</td>
					  <td>'.$district.'</td>
					  <td>
						  <button class="btn btn-primary"><a href="Account_updateC.php?updateid='.$cc_id.'" class="text-light">Update</a></button>
						  <button class="btn btn-danger"><a href="Account_delete.php?deleteid='.$cc_id.'" class="text-light">Delete</a></button>
					  </td>
					</tr>';
				}
			}
		  
		  ?>
		  </tbody>
		</table>
		
		<button class="btn btn-primary my-5"><a href="Account_addUserL.php" class="text-light">add user</a>
		</button>
		<table class="table">
		  <thead>
			<tr>
			  <th scope="col">User ID</th>
			  <th scope="col">Name</th>
			  <th scope="col">Email</th>
			  <th scope="col">Phone</th>
			  <th scope="col">Subject/Course</th>
			  <th scope="col">Gender</th>
			  <th scope="col">District</th>
			  <th scope="col">Operations</th>
			</tr>
		  </thead>
		  <tbody>
		  
		  
		  
		  
		  <?php
			
			$sql="Select * from lecturer";
			$result=mysqli_query($connection, $sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
					$lec_id=$row['lec_id'];
					$lec_name=$row['lec_name'];
					$email=$row['email'];
					$contact_num=$row['contact_num'];
					$subject=$row['subject'];
					$gender=$row['gender'];
					$district=$row['district'];
					echo'<tr>
					  <th scope="row">'.$lec_id.'</th>
					  <td>'.$lec_name.'</td>
					  <td>'.$email.'</td>
					  <td>'.$contact_num.'</td>
					  <td>'.$subject.'</td>
					  <td>'.$gender.'</td>
					  <td>'.$district.'</td>
					  <td>
						  <button class="btn btn-primary"><a href="Account_updateL.php?updateid='.$lec_id.'" class="text-light">Update</a></button>
						  <button class="btn btn-danger"><a href="Account_delete.php?deleteid='.$lec_id.'" class="text-light">Delete</a></button>
					  </td>
					</tr>';
				}
			}
		  
		  ?>
		  </tbody>
		</table>
		
		<button class="btn btn-primary my-5"><a href="Account_addUserS.php" class="text-light">add user</a>
		</button>
		<table class="table">
		  <thead>
			<tr>
			  <th scope="col">User ID</th>
			  <th scope="col">Name</th>
			  <th scope="col">Email</th>
			  <th scope="col">Phone</th>
			  <th scope="col">Subject/Course</th>
			  <th scope="col">Gender</th>
			  <th scope="col">District</th>
			  <th scope="col">Operations</th>
			</tr>
		  </thead>
		  <tbody>
		  
		  
		  
		  
		  <?php
			
			$sql="Select * from student";
			$result=mysqli_query($connection, $sql);
			if($result){
				while($row=mysqli_fetch_assoc($result)){
					$st_id=$row['st_id'];
					$st_name=$row['st_name'];
					$email=$row['email'];
					$contact_num=$row['contact_num'];
					$course=$row['course'];
					$gender=$row['gender'];
					$district=$row['district'];
					echo'<tr>
					  <th scope="row">'.$st_id.'</th>
					  <td>'.$st_name.'</td>
					  <td>'.$email.'</td>
					  <td>'.$contact_num.'</td>
					  <td>'.$course.'</td>
					  <td>'.$gender.'</td>
					  <td>'.$district.'</td>
					  <td>
						  <button class="btn btn-primary"><a href="Account_updateS.php?updateid='.$st_id.'" class="text-light">Update</a></button>
						  <button class="btn btn-danger"><a href="Account_delete.php?deleteid='.$st_id.'" class="text-light">Delete</a></button>
					  </td>
					</tr>';
				}
			}
		  
		  ?>
		  </tbody>
		</table>
	</div>
</body>
</html>
<?php mysqli_close($connection); ?>