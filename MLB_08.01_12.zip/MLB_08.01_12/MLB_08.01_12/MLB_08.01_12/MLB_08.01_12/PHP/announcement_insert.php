<?php 
	//DB Connection
    include "announcement_config.php";

    //Data
    $announcement=$_REQUEST["announcement"];

    //Query to INSERT
  	$sql = "INSERT INTO announcements(announcement) VALUES('$announcement')";
  
  	//Execution and testing
  	$result = $conn->query($sql);
  	if ($result == TRUE) {
    	header('Location: announcement.php');
  	}
  	else
  	{
  	  echo "Error:". $sql . "<br>". $conn->error;
 	  }

?>