
<?php 
// DB conncetion
include "register_config.php";

$sql = "SELECT * FROM student";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Page of Student Database</title>

    <link rel="stylesheet" type="text/css" href="../css/header.css">
    <link rel="stylesheet" type="text/css" href="../css/general.css">

</head>

<body>

    <!-- Header --> 
    <div >

        <center>
        <img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

        </center>
        
        <!-- Navigation Bar --> 
            <ul style="font-family: Arial, Helvetica, sans-serif;">  
                <li><a class="active" href="home_page.php">Home</a></li>
                <li><a href="Courses.php">Courses</a></li>
                <li><a href="Download.php">Download</a></li>
                <li><a href="announcement.php">Announcements</a></li>   
                <li><a href="enroll.php">Enroll</a></li>
                <li><a href="feedback.php">Feedbacks</a></li>
                <li><a href="Account.php">Account</a></li>
                <li><a href="staffPage.php">Staff</a></li>
                <li><a href="login.php">Log in</a></li>
                <li><a href="register.php" >Register now</a></li>
            </ul>
    </div>

    <!-- end of the header --> 
    <br>

    <div class="container" style="padding-top: 30px; padding-bottom: 30px;">

        <h2>Student Database Upadate/Delete Page</h2>

        <!-- view table -->
        <table class="table" style="border: 1px solid black;">

            <thead>
                <tr style="border: 1px solid black;">
                    <th style="border: 1px solid black; margin: 10px; padding: 10px;">St_id</th>
                    <th style="border: 1px solid black;">Name</th>
                    <th style="border: 1px solid black;">Age</th>
                    <th style="border: 1px solid black;">NIC</th>
                    <th style="border: 1px solid black;">Contact_num</th>
                    <th style="border: 1px solid black;">Street_address</th>
                    <th style="border: 1px solid black;">City</th>
                    <th style="border: 1px solid black;">Province</th>
                    <th style="border: 1px solid black;">Email</th>
                    <th style="border: 1px solid black;">Password</th>
                    <th style="border: 1px solid black;">Action</th>
                </tr>

            </thead>

            <tbody> 

                <?php
                    if ($result->num_rows > 0) {
                     while ($row = $result->fetch_assoc()) {
                ?>

                            <tr style="border: 1px solid black;">
                                <td style="border: 1px solid black;"><?php echo $row['St_id']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Name']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Age']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['NIC']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Contact_num']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Street_address']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['City']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Province']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Email']; ?></td>
                                <td style="border: 1px solid black;"><?php echo $row['Password']; ?></td>
                                <td style="border: 1px solid black;">
                                    <button><a  href="register_update.php?id=<?php echo $row['St_id']; ?>">Edit</a></button>
                                    <button><a  href="register_delete.php?id=<?php echo $row['St_id']; ?>">X</a></button>
                                </td>
                            </tr>                       

                <?php       
                    }

                    }

                ?>                

            </tbody>
        </table>
    </div>

    <!-- Footer -->
    
    <div class="coldiv">

                
                <div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
                    <table class="font">
                        <tr style="font-size: larger; color: #2e7d4d;">
                            <th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
                            <th style="width: 30%;">Useful Links</th>
                            <th style="width: 30%;">Our Social Networks</th>
                        </tr>

                        <tr>
                            <td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
                        

                            
                            <td style="padding-left: 170px;" >
                                <a href="home_page.php" class="link">Home</a><br>
                                <a href="Courses.php" class="link">Courses</a><br>
                                <a href="Download.php" class="link"> Download</a><br>
                                <a href="announcement.php" class="link"> Announcements</a><br>
                                <a href="enroll.php" class="link">Enroll</a><br>
                                <a href="feedback.php" class="link">Feedbacks</a><br>
                                <a href="Account.php" class="link">Account</a><br>
                                <a href="staffPage.php" class="link">Staff</a><br>
                                <a href="login.php" class="link">Log in</a><br>
                                <a href="register.php" class="link">Register</a>
                            </td>

                            <td style="padding-left: 110px; padding-top: 20px;">
                                <div class="SocialLogos">
                                    <p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
                                    <a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
                                    <a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
                                    <a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
                                     
                                </div>
                            </td>


                        </tr>

                    </table>
                
                </div>
                    <center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 -edeze - Online Teacher Training School - All Right Reserved</h3></center>
            </div>

    <!-- End of the Footer  --> 

</body>

</html>