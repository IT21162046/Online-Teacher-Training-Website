<?php
    $dbhost = '127.0.0.1';
    $dbuser = 'root';
    $dbpass = '';
    $dbname = 'iwt_assignment';

    // // $conn = mysqli_connect([host], [username], [password], [database name]);

    // $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

    // // if the db connection fails, dispaly an error message and exit
    if(!$conn){
        die('could not connect:'. mysqli_error($conn));
    }
    // // //select the database
    mysqli_select_db($conn,$dbname);

?> 