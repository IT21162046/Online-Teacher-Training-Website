<?php 

include "enroll_config.php";

$sql = "SELECT * FROM enroll";

$result = $conn->query($sql);

?>

<!DOCTYPE html>


<html>

<head>

    <title>View Page of Enroll Database</title>

    <link rel="stylesheet"  href="../css/enroll_view.css">

</head>

<body>

  

        <h2>Enroll students</h2>

<table class="content-table">

    <thead>

        <tr>

        <th>Username</th>

        <th>Full_Name</th>

        <th>Contact_number</th>
		
		<th>Email</th>

        <th>Course name</th>
		
		<th>Action</th>

    </tr>
    
    </thead>

    <tbody> 

        <?php

            if ($result->num_rows > 0) {

                while ($row = $result->fetch_assoc()) {

        ?>

                    <tr>

                    <td><?php echo $row['Username']; ?></td>

                    <td><?php echo $row['Sname']; ?></td>

                    <td><?php echo $row['Contact_num']; ?></td>
					
					<td><?php echo $row['Email']; ?></td>

                    <td><?php echo $row['Course_name']; ?></td>


                    <td>
                        <a class="btn btn-info btn-sm" href="enroll_update.php?id=<?php echo $row['Username']; ?>"><input type="submit" value="Update"></a>
                        <a class="btn btn-danger btn-sm" href="enroll_delete.php?id=<?php echo $row['Username']; ?>"><input type="submit" value="Delete"</a>
                    </td>

                    </tr>                       

        <?php       
            }

            }

        ?>                

    </tbody>

</table>

  

</body>

</html>