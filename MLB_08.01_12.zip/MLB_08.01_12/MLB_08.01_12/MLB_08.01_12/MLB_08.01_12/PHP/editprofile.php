<?php require_once('connection.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit profile</title>
	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="../css/Account.css">
	

</head>
<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
			<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			  	<li><a href="home page.php">Home</a></li>
			  	<li><a href="Courses.php">Courses</a></li>
			  	<li><a href="Download.php">Download</a></li>
			  	<li><a href="announcement.php">Announcements</a></li>	
			  	<li><a href="enroll.php">Enroll</a></li>
			  	<li><a href="feedback.php">Feedbacks</a></li>
			  	<li><a class="active" href="Account.php">Account</a></li>
			  	<li><a href="staffPage.php">Staff</a></li>
			  	<li><a href="login.php">Log in</a></li>
			  	<li><a href="register.php" >Register now</a></li>
			</ul>
	</div>

	<!-- end of the header --> 
	
	<center>
		<div style="max-width:424px; background-color: #f5f2f0; padding-top: 25px; padding-bottom: 40px; margin-top: 80px; margin-bottom: 80px; border-radius: 25px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)">
		
		<div class="row">

        <div class="col-md-12">
          <form name="basicForm" ng-submit="submitForm(basicForm.$valid)" class="form-horizontal form-bordered" novalidate>
          <div class="panel panel-default">
              <div class="panel-heading">
                <h1 class="panel-title">User Details</h1>
              </div>
              <div class="panel-body">
                <div class="form-group">
                  <label class="col-sm-3 control-label">Name </label>
                  <div class="col-sm-9">
                    <input ng-model="user.name" type="text" name="name" class="form-control" placeholder="Type your name..." required />
                  </div>
                </div><br>

                <div class="form-group">
                  <label class="col-sm-3 control-label">Email </label>
                  <div class="col-sm-9">
                    <input ng-model="user.email" type="email" name="email" class="form-control" placeholder="Type your email..." required />
                  </div>
                </div><br>

                <div class="form-group">
                  <label class="col-sm-3 control-label">Phone </label>
                  <div class="col-sm-9">
                    <input ng-model="user.phone" type="tel" name="phone" class="form-control" placeholder="Type your phone number..." required />
                  </div>
                </div><br>

                <div class="form-group">
                  <label class="col-sm-3 control-label">District </label>
                  <div class="col-sm-9">
                    <textarea ng-model="user.district" rows="3" class="form-control" placeholder="Type your district..." required></textarea>
                  </div>
                </div>
              </div><!-- panel-body -->
          </div><!-- panel -->



              <div class="panel-footer">
                <div class="row">
                  <div class="col-sm-9 col-sm-offset-3">
                    <button onclick="myFunction()" class="btn btn-primary">Save</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                  </div>
                </div>
              </div>
		
          </form>
        </div><!-- col-md-6 -->
        </div>
	    </div>
	</center>
      <!-- end personal info form -->
	  
	  <script>
	jQuery(document).ready(function(){

	  // Chosen Select
	  jQuery(".chosen-select").chosen({'width':'100%','white-space':'nowrap'});

	  // Tags Input
	  jQuery('#tags').tagsInput({width:'auto'});

	  // Textarea Autogrow
	  jQuery('#autoResizeTA').autogrow();

	  // Color Picker
	  if(jQuery('#colorpicker').length > 0) {
		 jQuery('#colorSelector').ColorPicker({
				onShow: function (colpkr) {
					jQuery(colpkr).fadeIn(500);
					return false;
				},
				onHide: function (colpkr) {
					jQuery(colpkr).fadeOut(500);
					return false;
				},
				onChange: function (hsb, hex, rgb) {
					jQuery('#colorSelector span').css('backgroundColor', '#' + hex);
					jQuery('#colorpicker').val('#'+hex);
				}
		 });
	  }

	  // Color Picker Flat Mode
		jQuery('#colorpickerholder').ColorPicker({
			flat: true,
			onChange: function (hsb, hex, rgb) {
				jQuery('#colorpicker3').val('#'+hex);
			}
		});

	  // Date Picker
	  jQuery('#datepicker').datepicker();

	  jQuery('#datepicker-inline').datepicker();

	  jQuery('#datepicker-multiple').datepicker({
	    numberOfMonths: 3,
	    showButtonPanel: true
	  });

	  // Spinner
	  var spinner = jQuery('#spinner').spinner();
	  spinner.spinner('value', 0);

	  // Input Masks
	  jQuery("#date").mask("99/99/9999");
	  jQuery("#phone").mask("(999) 999-9999");
	  jQuery("#ssn").mask("999-99-9999");

	  // Time Picker
	  jQuery('#timepicker').timepicker({defaultTIme: false});
	  jQuery('#timepicker2').timepicker({showMeridian: false});
	  jQuery('#timepicker3').timepicker({minuteStep: 15});


	});
	
	function myFunction() {
			  alert("Successfully updated profile! \n       back to account");
			}
	</script>
	
	
<!-- Footer -->
	
	<div class="coldiv">

				
				<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
					<center>
					<table class="font">
						<tr style="font-size: larger; color: #2e7d4d;">
							<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
							<th style="width: 30%;">Useful Links</th>
							<th style="width: 30%;">Our Social Networks</th>
						</tr>

						<tr>
							<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
						

							
							<td style="padding-left: 170px;" >
								<a href="home page.php" class="link">Home</a><br>
								<a href="Courses.php" class="link">Courses</a><br>
								<a href="Download.php" class="link"> Download</a><br>
								<a href="announcement.php" class="link"> Announcements</a><br>
								<a href="enroll.php" class="link">Enroll</a><br>
								<a href="feedback.php" class="link">Feedbacks</a><br>
								<a href="Account.php" class="link">Account</a><br>
								<a href="staffPage.php" class="link">Staff</a><br>
								<a href="login.php" class="link">Log in</a><br>
								<a href="register.php" class="link">Register</a>
							</td>

							<td style="padding-left: 110px; padding-top: 20px;">
								<div class="SocialLogos">
									<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
									<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
									<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
									<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
									 
								</div>
							</td>


						</tr>

					</table>
					</center>
				
				</div>
					<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 - edeze - Online Teacher Training School - All Right Reserved</h3></center>
			</div>

	<!-- End of the Footer  -->


</body>
</html>
<?php mysqli_close($connection); ?>