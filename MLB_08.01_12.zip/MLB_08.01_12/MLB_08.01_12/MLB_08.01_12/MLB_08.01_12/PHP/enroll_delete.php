<?php 

include "enroll_config.php"; 

if (isset($_GET['id'])) {

    $username = $_GET['id'];

    $sql = " DELETE FROM enroll WHERE username='$username' ";

     $result = $conn->query($sql);

     if ($result == TRUE) {

        echo "Record deleted successfully.";

    }else{

        echo "Error:" . $sql . "<br>" . $conn->error;

    }

} 

?>



