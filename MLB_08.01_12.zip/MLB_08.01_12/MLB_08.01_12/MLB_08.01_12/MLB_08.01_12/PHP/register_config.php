<?php
    $servername = "localhost";
    $username_db = "root"; 
    $password_db = ""; 
    $dbname_db = "online_teacher_trainer";

    $conn = new mysqli($servername, $username_db, $password_db, $dbname_db);

    //check the connection for errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else
    {
    	//echo "success";
    }
?>
