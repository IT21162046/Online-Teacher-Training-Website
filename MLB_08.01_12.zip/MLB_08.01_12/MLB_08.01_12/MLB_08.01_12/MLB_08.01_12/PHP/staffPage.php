<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  *{
    margin: 0;
  }
.main{
  display: grid;
  grid-gap: 1px;
  grid-template-columns: 1fr 1fr;
}
.image{
  padding-bottom: 0px;
  height : 450px;
  width: 450px;
  margin-bottom: 85px;
  box-shadow: rgba(0, 0, 0, 0.3) 0px 19px 38px, rgba(0, 0, 0, 0.22) 0px 15px 12px;
}
.container {
  margin-left: auto;
  margin-right: auto;
  position: relative;
  width: 65%;
}
.overlay {
  position:absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  height: 83.5%;
  /* width: 100%; */
  width: 450px;
  opacity: 0;
  transition: .5s ease;
  background-color: #3d8f3da9;
}

.container:hover .overlay {
  opacity: 1;
}

.text {
  color: whitesmoke;
  font-size: 20px;
  position: absolute;
  top: 50%;
  left: 50%;
  -webkit-transform: translate(-50%, -50%);
  -ms-transform: translate(-50%, -50%);
  transform: translate(-50%, -50%);
  text-align: center;
}

.main-group{
width: 100%;
}
.h2{
  text-align: center;
  margin-top: 5%;
  margin-bottom: 5%;
  font-size: 36px;
}

</style>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/homepage.css">
	<link rel="stylesheet" type="text/css" href="../css/loginPagePopup.css">

</head>
<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" >

		</center>
		
		<!-- Navigation Bar --> 
			<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			  	<li><a href="home_page.php">Home</a></li>
			  	<li><a href="Courses.php">Courses</a></li>
			  	<li><a href="Download.php">Download</a></li>
			  	<li><a href="announcement.php">Announcements</a></li>	
			  	<li><a href="enroll.php">Enroll</a></li>
			  	<li><a href="feedback.php">Feedbacks</a></li>
			  	<li><a href="Account.php">Account</a></li>
			  	<li><a class="active" href="staffPage.php">Staff</a></li>
			  	<li><a href="loginPage.php">Log in</a></li>
			  	<li><a href="register.php">Register now</a></li>
			</ul>
	</div>

</head>
<body>

<img src="../images/stuffImg/istock000050895978medium_1024xx1784-1001-0-73.jpg" alt="" srcset="" class="main-group">
<h2 class="h2">Meet the team that's steering Online Teacher Tranning School into the future.</h2>
<div class="main">
  <div class="container">
    <img src="../images/stuffImg/Bertram_Haley-400x400.jpg" alt="Avatar" class="image">
    <div class="overlay">
      <div class="text">Professor Kristi Gordon holds a degree in Electronics and Telecommunication Engineering from the University of Oxford and a PhD from Saga University, Japan. Her areas of research include robotics, intelligence systems, and the Internet.</div>
    </div>
  </div>
  <div class="container">
    <img src="../images/stuffImg/pixomatic_1572877223091.png" alt="Avatar" class="image">
    <div class="overlay">
      <div class="text">Dr. kelvin colin is currently the Vice Chancellor and Computer Science Professor of Online techer tarnning school. HE Gordon holds a degree in Network Engineering from the University of Cambrige.</div>
    </div>
  </div>
  <div class="container">
    <img src="../images/stuffImg/Paul_Iannello_400.jpg" alt="Avatar" class="image">
    <div class="overlay">
      <div class="text">Dr. Chris Gailus is currently the Vice Chancellor and Business Adminstartion Professor of Online Teacher Tranning School. He Gordon holds a degree in Business Adminstartion from the USA.</div>
    </div>
  </div>
  <div class="container">
    <img src="../images/stuffImg/download.jpg" alt="Avatar" class="image">
    <div class="overlay">
      <div class="text">Professor Jacqui Cohen is currently Information and Communication Technology of Online Teacher Tranning School. He Gordon holds a degree in Information Technology from the UK.</div>
    </div>
  </div>
  <div class="container">
    <img src="../images/stuffImg/Mihajlovich_Brooke_web-400x400.jpg" alt="Avatar" class="image">
    <div class="overlay">
      <div class="text">Professor Sonia Sunger is currently Business Information Systems of Online Teacher Tranning School. He Gordon holds a degree in Business Information Systems from the University of Cambrige.</div>
    </div>
  </div>
  <div class="container">
    <img src="../images/stuffImg/staff_profile_400_x_400_xilonem_lopez_2.jpg" alt="Avatar" class="image">
    <div class="overlay">
      <div class="text">Professor Katelin Owsianski is currently Computer Science and Engineering of Online Teacher Tranning School. He Gordon holds a degree in Computer Science and Engineering from the University of Cambrige.</div>
    </div>
  </div>
</div>
	<!-- Footer -->
	
	<div class="coldiv">

				
    <div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
      <table class="font">
        <tr style="font-size: larger; color: #2e7d4d;">
          <th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
          <th style="width: 30%;">Useful Links</th>
          <th style="width: 30%;">Our Social Networks</th>
        </tr>

        <tr>
          <td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
        

          
          <td style="padding-left: 170px;" >
            <a href="home_page.php" class="link">Home</a><br>
            <a href="Courses.php" class="link">Courses</a><br>
            <a href="Download.php" class="link"> Download</a><br>
            <a href="announcement.php" class="link"> Announcements</a><br>
            <a href="enroll.php" class="link">Enroll</a><br>
            <a href="feedback.php" class="link">Feedbacks</a><br>
            <a href="Account.php" class="link">Account</a><br>
            <a href="staffPage.php" class="link">Staff</a><br>
            <a href="login.php" class="link">Log in</a><br>
            <a href="register.php" class="link">Register</a>
          </td>

          <td style="padding-left: 130px; padding-bottom: 50px;">
            <div class="SocialLogos">
              <p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
              <a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FBLogo.png" alt="Facebook"></a> 
              <a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram"></a> 
              <a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter"></a>
               
            </div>
          </td>


        </tr>

      </table>

    </div>

      <h3 style="padding-top: 10px; padding-bottom: 25px; color: black; text-align: center;">Copyright &#169; 2020 - Online Teacher Training School - All Right Reserved</h3>						
    </div>
<!-- End of the Footer  -->



</body>
</html>
