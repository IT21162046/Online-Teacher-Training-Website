<?php 
  //DB Connection
  include "register_config.php";

  // Data
  $user_name = $_POST['username'];
  $age = $_POST['age'];
  $id_num = $_POST['NIC'];
  $contact_num = $_POST['contact'];
  $street_address = $_POST['street'];
  $city = $_POST['city'];
  $province = $_POST['province'];
  $email = $_POST['email'];
  $password = $_POST['passid'];

  //Query to INSERT
  $sql = "INSERT INTO student(Name,Age,NIC,Contact_num,Street_address,City,Province,Email,Password) VALUES('$user_name','$age','$id_num','$contact_num','$street_address','$city','$province','$email','$password')";
  
  //Execution and testing
  $result = $conn->query($sql);
  if ($result == TRUE) {
    echo "New record created successfully.";
    header('Location: register.php');
  }
  else
  {
    echo "Error:". $sql . "<br>". $conn->error;
  }
?>