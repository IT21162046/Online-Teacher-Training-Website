<?php require_once('connection.php'); 

	$admin_id=$_GET['updateid'];
	$sql="select * from admin where admin_id='$admin_id'";
	$result=mysqli_query($connection, $sql);
	$row=mysqli_fetch_assoc($result);
	$admin_id=$row['admin_id'];
	$admin_name=$row['admin_name'];
	$email=$row['email'];
	$contact_num=$row['contact_num'];
	$course=$row['course'];
	$gender=$row['gender'];
	$district=$row['district'];
	
	if(isset($_POST['submit'])){
		$admin_id=$_POST['admin_id'];
		$admin_name=$_POST['admin_name'];
		$email=$_POST['email'];
		$contact_num=$_POST['contact_num'];
		$course=$_POST['course'];
		$gender=$_POST['gender'];
		$district=$_POST['district'];
		
		$sql="update admin set admin_id='$admin_id', admin_name='$admin_name', email='$email', contact_num='$contact_num', course='$course', gender='$gender', district='$district' where admin_id='$admin_id'";
		$result=mysqli_query($connection,$sql);
		if($result){
			//echo "Updated successfully";
			 header('location:Account_display.php');
		}else{
			die(mysqli_error($connection));
		}
	}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1, shrink-to-fit=no">
	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<title>Update user details</title>
</head>
<body>
	<div class="container my-5">
		<form method="post">
		  <div class="form-group">
			<label>User Id</label>
			<input type="text" class="form-control" placeholder="Enter your user id" name="admin_id" value=<?php echo $admin_id;?>>
		  </div>
		   <div class="form-group">
			<label>Name</label>
			<input type="text" class="form-control" placeholder="Enter your name" name="admin_name" value=<?php echo $admin_name;?>>
		  </div>
		   <div class="form-group">
			<label>Email</label>
			<input type="email" class="form-control" placeholder="Enter your email" name="email" value=<?php echo $email;?>>
		  </div>
		   <div class="form-group">
			<label>Contact Number</label>
			<input type="text" class="form-control" placeholder="Enter your contact nummber" name="contact_num" value=<?php echo $contact_num;?>>
		  </div>
		   <div class="form-group">
			<label>Course/Subject</label>
			<input type="text" class="form-control" placeholder="Enter your course/subject" name="course" value=<?php echo $course;?>>
		  </div>
		   <div class="form-group">
			<label>Gender</label>
			<input type="text" class="form-control" placeholder="Enter your gender" name="gender" value=<?php echo $gender;?>>
		  </div>
		   <div class="form-group">
			<label>District</label>
			<input type="text" class="form-control" placeholder="Enter your district" name="district" value=<?php echo $district;?>>
		  </div>
		  
		  <button type="submit" name="submit" class="btn btn-primary">Update</button>
		</form>
	</div>
				
</body>
</html>
<?php mysqli_close($connection); ?>