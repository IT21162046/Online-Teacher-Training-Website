<?php require_once('connection.php'); ?>
<!DOCTYPE html>
<html>
<head>
	<title>Change password</title>
	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="styles.css" />
	

</head>
<body>

<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
			<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			  	<li><a href="home page.php">Home</a></li>
			  	<li><a href="Courses.php">Courses</a></li>
			  	<li><a href="Download.php">Download</a></li>
			  	<li><a href="announcement.php">Announcements</a></li>	
			  	<li><a href="enroll.php">Enroll</a></li>
			  	<li><a href="feedback.php">Feedbacks</a></li>
			  	<li><a class="active" href="Account.php">Account</a></li>
			  	<li><a href="staffPage.php">Staff</a></li>
			  	<li><a href="login.php">Log in</a></li>
			  	<li><a href="register.php" >Register now</a></li>
			</ul>
	</div>

<!-- end of the header -->

	<?php
		include("passwordreal.php");
	?>
	
	<center>
		<div style="max-width:424px; background-color: #f5f2f0; padding-bottom: 134px; padding-left: 30px; margin-top: 80px; margin-bottom: 80px; border-radius: 25px; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19)">
			<form name="frmChange" method="post" action="" onSubmit="return validatePassword()">
				<div style="width:500px;">
				<div class="message"><?php if(isset($message)) { echo $message; } ?></div>
					<table border="0" cellpadding="10" cellspacing="0" width="500" align="center" style="padding-top: 100px;" class="tblSaveForm">
						<tr class="tableheader">
							<td colspan="2"><h1> &nbsp&nbsp&nbsp&nbsp&nbsp Change Password</h1></td>
						</tr>
						<tr>
							<td width="40%"><label>Current Password</label></td>
							<td width="60%"><input type="password" name="currentPassword" class="txtField"/><span id="currentPassword"  class="required"></span></td>
						</tr>
						<tr>
							<td><label>New Password</label></td>
							<td><input type="password" name="newPassword" class="txtField"/><span id="newPassword" class="required"></span></td>
						</tr>
						<tr>
							<td><label>Confirm Password</label></td>
							<td><input type="password" name="confirmPassword" class="txtField"/><span id="confirmPassword" class="required"></span></td>
						</tr>
						<tr>
							<td colspan="2"><center><input type="submit" name="submit" value="Submit" class="btnSubmit"><center></td>
						</tr>
					</table>
				</div>
			</form>
		</div>
	</center>
	
	<script>
		function validatePassword() {
		var currentPassword,newPassword,confirmPassword,output = true;

		currentPassword = document.frmChange.currentPassword;
		newPassword = document.frmChange.newPassword;
		confirmPassword = document.frmChange.confirmPassword;

		if(!currentPassword.value) {
		currentPassword.focus();
		document.getElementById("currentPassword").innerHTML = "required";
		output = false;
		}
		else if(!newPassword.value) {
		newPassword.focus();
		document.getElementById("newPassword").innerHTML = "required";
		output = false;
		}
		else if(!confirmPassword.value) {
		confirmPassword.focus();
		document.getElementById("confirmPassword").innerHTML = "required";
		output = false;
		}
		if(newPassword.value != confirmPassword.value) {
		newPassword.value="";
		confirmPassword.value="";
		newPassword.focus();
		document.getElementById("confirmPassword").innerHTML = "not same";
		output = false;
		} 	
		return output;
		}
			
	</script>  

<!-- Footer -->
	
	<div class="coldiv">

				
				<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
					<center>
					<table class="font">
						<tr style="font-size: larger; color: #2e7d4d;">
							<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
							<th style="width: 30%;">Useful Links</th>
							<th style="width: 30%;">Our Social Networks</th>
						</tr>

						<tr>
							<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
						

							
							<td style="padding-left: 170px;" >
								<a href="home page.php" class="link">Home</a><br>
								<a href="" class="link">Courses</a><br>
								<a href="Download.php" class="link"> Download</a><br>
								<a href="" class="link"> Announcements</a><br>
								<a href="" class="link">Enroll</a><br>
								<a href="feedback.php" class="link">Feedbacks</a><br>
								<a href="Account.php" class="link">Account</a><br>
								<a href="" class="link">Staff</a><br>
								<a href="" class="link">Log in</a><br>
								<a href="register.php" class="link">Register</a>
							</td>

							<td style="padding-left: 110px; padding-top: 20px;">
								<div class="SocialLogos">
									<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
									<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
									<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
									<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
									 
								</div>
							</td>


						</tr>

					</table>
					</center>
				
				</div>
					<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 - edeze - Online Teacher Training School - All Right Reserved</h3></center>
			</div> 

	<!-- End of the Footer  -->
	
</body>

</html>
<?php mysqli_close($connection); ?>