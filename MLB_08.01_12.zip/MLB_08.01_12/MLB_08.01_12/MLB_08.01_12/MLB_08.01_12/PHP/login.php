<!-- PHP -->
<?php

	session_start();
	include("../php/db.php");
	// define variables and set to empty values
	$name = $password = $switch = $SQL ="";
	$executeSql = null;

	echo '<script>console.log("Login PHP")</script>';

	if ($_SERVER["REQUEST_METHOD"] == "POST") {

		echo '<script>console.log("Request method post")</script>';

		$name = test_input($_POST["username"]);
		$password = test_input($_POST["userPassword"]);
		$switch = test_input($_POST["tableName"]);
		
		if($switch == "adminlogin"){
			$SQL = "SELECT name, password FROM adminLogin WHERE name= '" . $name . "' AND password= '" . $password ."';";
		}elseif($switch =="lecturerlogin" ){
			$SQL = "SELECT name, password FROM lecturetLogin WHERE name='" . $name . "' AND password= '" . $password .";";
		}elseif("studentlogin" == $switch){
			$SQL = "SELECT name, password FROM studentLogin WHERE name='" . $name . "' AND password= '" . $password ."';";
		}
		

		$executeSql = $conn->query($SQL);
		
		while($array = $executeSql->fetch_assoc()){
		
			if ($name == $array["name"] && $password == $array["password"]) {
				$_SESSION['username'] = $userName;
				// header("Location: home_page.php");
				echo '<script type ="text/javascript">alert("Successfully logged in!");</script>';
				echo '<script type ="text/javascript">location.replace("./home_page.php");</script>';
			}else{
				echo '<script>console.log("Incorrect password")</script>';
				echo '<script type ="text/javascript">alert("Password Or Username is Invalid!");</script>';
				echo '<script type ="text/javascript">location.replace("./home_page.php");</script>';
			}
		}


	}else{ 

		echo '<script>console.log("Request Method Get")</script>';

		$name = $_GET["username"];
		$password = $_GET["userPassword"];
		$switch = $_GET["tableName"];

		echo $name , $password , $switch;
		
		if($switch == "adminlogin"){
			$SQL = "SELECT name, password FROM adminLogin WHERE name=" . $name . " AND password=" . $password . ";";
		}elseif($switch =="lecturerlogin" ){
			$SQL = "SELECT name, password FROM lecturetLogin WHERE name=" . $name . " AND password=" . $password . ";";
		}elseif("studentlogin" == $switch){
			$SQL = "SELECT name, password FROM studentLogin WHERE name=" . $name . " AND password=" . $password . ";";
		}
		
		echo $SQL;
		$executeSql = $conn->query($SQL);
		
		while($array = $executeSql->fetch_assoc()){
		
			if ($name == $array["name"] && $password == $array["password"]) {
				$_SESSION['username'] = $userName;
				// header("Location: home_page.php");
				
				echo '<script type ="text/javascript">alert("Successfully logged in!");</script>';
				echo '<script type ="text/javascript">location.replace("home_page.php");</script>';
			}else{
				
				echo '<script type ="text/javascript">alert("Password Or Username is Invalid!");</script>';
				echo '<script type ="text/javascript">location.replace("home_page.php");</script>';
			}
		}

	}



	function test_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

?>
