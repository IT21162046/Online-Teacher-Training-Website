<?php
    $servername= "localhost";

    $username="root";
	
    $password="";
	
    $dbname= "enroll_db";

    $conn =new mysqli($servername,$username,$password,$dbname);

    //check the connection for errors
     if ($conn->connect_error)
      {
        die("Connection failed: " . $conn->connect_error);
       }
	   else
    {
    	//echo "success";
    }

?>
