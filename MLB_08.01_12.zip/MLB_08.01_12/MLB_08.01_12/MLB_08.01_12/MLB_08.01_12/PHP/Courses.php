<html>
<head>

	<title>Courses</title>

	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet"  href="../css/mycourses.css">
	

</head>
<body>
    <!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
		<ul style="font-family: Arial, Helvetica, sans-serif;">
			
			<li><a href="home_page.php">Home</a></li>
			<li><a class="active" href="Courses.php">Courses</a></li>
			<li><a href="Download.php">Download</a></li>
			<li><a href="announcement.php">Announcements</a></li>	
			<li><a href="enroll.php">Enroll</a></li>
			<li><a href="feedback.php">Feedbacks</a></li>
			<li><a href="Account.php">Account</a></li>
			<li><a href="staffPage.php">Staff</a></li>
			<li><a href="loginPage.php">Log in</a></li>
			<li><a href="register.php">Register now</a></li>
		</ul>
	</div>

	

	<!-- end of the header --> 
	
     <img src="../images/Courses/g5.jpg" alt="download" width="100%" height="200px">
	 <div class="h1">   <center> Diploma Courses </div>
	 <div class="row">
	 <div class="column">
	 <div class="image">
	     <img class="image__img" src= "../images/Courses/p4.jpg"  alt="nooooo"> 
		 <a href="../html/Primary.html">
		<div class="image__overlay image__overlay--primary">
		<div class="image__title">DIPLOMA</div>
		<p class="image__description">
		   Primary teaching 
		   </p>
		   </div>
		  </div>
		  </a>
		  <h3> <center> Diploma in Primary Teaching  </h3>
		  </div>
		  
		 
		 <div class="column">
        <div class="image">
	     <img class="image__img" src= "../images/Courses/p1.jpg"  alt="nooooo">
		 <a href="../html/pre-school.html">
		<div class="image__overlay image__overlay--primary">
		<div class="image__title">DIPLOMA</div>
		<p class="image__description">
		   Pre-school Education
		   </p>
		   </div>
		  </div>
		  </a>
		  <h3> <center> Diploma in Pre-school Education </h3>
		  </div>
		  
		  <div class="column">
		  <div class="image">
	     <img class="image__img" src= "../images/Courses/ee.jpg"  alt="nooooo">
		 <a href="../html/English.html">
		<div class="image__overlay image__overlay--primary">
		<div class="image__title">DIPLOMA</div>
		<p class="image__description">
		   Teaching English Language and literature
		   </p>
		   </div>
		  </div>
		  </a>
		  <h3> <center> Diploma Teaching English Language & literature </h3>
		  </div>
		  </div>
		  
        <!-- Computer Courses --> 
		  <div class="h1">   <center> Computer Courses </div> 
		  <div class="row">
	 <div class="column">
	 <div class="image">
	     <img class="image__img" src= "../images/Courses/c1.jpg"  alt="nooooo"> 
		 <a href="../html/cyber.html">
		<div class="image__overlay image__overlay--primary">
		<div class="image__title">Cyber Security</div>
		<p class="image__description">
		   for more
		   </p>
		   </div>
		  </div>
		  <h3> <center> Cyber Security Courses </h3>
		  </div>
		  
		 
		 <div class="column">
        <div class="image">
	     <img class="image__img" src= "../images/Courses/i2.jpg"  alt="nooooo" width="100px" height="265px">
		<a href="../html/interactive.html">
		<div class="image__overlay image__overlay--primary">
		<div class="image__title">Interactive media</div>
		<p class="image__description">
		  for more
		   </p>
		   </div>
		  </div>
		  </a>
		  <h3> <center> Interactive media courses </h3>
		  </div>
		  
		  <div class="column">
		  <div class="image">
	     <img class="image__img" src= "../images/Courses/s3.jpg"  alt="nooooo">
		 <a href="../html/software.html">
		<div class="image__overlay image__overlay--primary">
		<div class="image__title">Software Engineering</div>
		<p class="image__description">
		   for more
		   </p>
		   </div> 
		  </div>
		  </a>
		   <h3> <center> Software Engineering </h3>
		  </div>
		 
		  </div>
		  
		  
	<!-- Footer -->
	
	<div class="coldiv">

				
		<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
			<table class="font">
				<tr style="font-size: larger; color: #2e7d4d;">
					<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
					<th style="width: 30%;">Useful Links</th>
					<th style="width: 30%;">Our Social Networks</th>
				</tr>

				<tr>
					<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
				

					
					<td style="padding-left: 170px;" >
						<a href="home_page.php" class="link">Home</a><br>
						<a href="Courses.php" class="link">Courses</a><br>
						<a href="Download.php" class="link"> Download</a><br>
						<a href="announcement.php" class="link"> Announcements</a><br>
						<a href="enroll.php" class="link">Enroll</a><br>
						<a href="feedback.php" class="link">Feedbacks</a><br>
						<a href="Account.php" class="link">Account</a><br>
						<a href="staffPage.php" class="link">Staff</a><br>
						<a href="loginPage.php" class="link">Log in</a><br>
						<a href="register.php" class="link">Register</a>
					</td>

					<td style="padding-left: 110px; padding-top: 20px;">
						<div class="SocialLogos">
							<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
							<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
							<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
							<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 -edeze - Online Teacher Training School - All Right Reserved</h3></center>
	</div>


	<!-- End of the Footer  -->
	
</body>

</html>