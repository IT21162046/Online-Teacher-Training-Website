<html>
<head>

	<title>Download</title>

	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="../css/Download.css">

</head>

<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
			<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			  	<li><a href="home_page.php">Home</a></li>
			  	<li><a href="Courses.php">Courses</a></li>
			  	<li><a class="active" href="Download.php">Download</a></li>
			  	<li><a href="announcement.php">Announcements</a></li>	
			  	<li><a href="enroll.php">Enroll</a></li>
			  	<li><a href="feedback.php">Feedbacks</a></li>
			  	<li><a href="Account.php">Account</a></li>
			  	<li><a href="staffPage.php">Staff</a></li>
			  	<li><a href="login.php">Log in</a></li>
			  	<li><a href="register.php" >Register now</a></li>
			</ul>
	</div>

	<!-- end of the header --> 

	<center>
	<div class="rcorners">
		<div style="max-width:1200px; background-color: #f5f2f0; padding-top: 50px; padding-bottom: 30px; margin-top: 80px; margin-bottom: 80px; border-radius: 25px">
		
		<table class = "tuser" style = "padding-bottom: 50px">
			<tr>
				<td>
					<hr style="height:2px; width: 400px; color:green; background-color:green; margin-left:30px; margin-right:30px">
				</td>
				<td>
					<h2 style = "padding-top: 20px">Teachers Guide</h2>
				</td>
				<td>
					<hr style="height:2px; width: 400px; color:green; background-color:green; margin-right:30px; margin-left:30px">
				</td>
			</tr>
		</table>
		<table>
			<tr>
				<td>
					<img src="../images/book.png" width="70" height="80" style = "margin-left: 50px">
					<h4 style = "padding-right: 20px">Primary Teaching Course</h4>
					<a style = "margin-left:4px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/book.png" width="70" height="80" style = "margin-left: 64px">
					<h4 style = "padding-right: 20px">Secondary Teaching Course</h4>
					<a style = "margin-left:14px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/book.png" width="70" height="80" style = "margin-left: 60px">
					<h4 style = "padding-right: 20px">Pre-School Teaching Course</h4>
					<a style = "margin-left:16px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/book.png" width="70" height="80" style = "margin-left: 64px">
					<h4 style = "padding-right: 20px">Special Needs Teaching Course</h4>
					<a style = "margin-left:19px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/book.png" width="70" height="80" style = "margin-left: 40px">
					<h4 style = "padding-right: 20px">Music Teaching Course</h4>
					<a href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
			</tr>
		</table>
		<table class = "tuser" style = "padding-top: 50px; padding-bottom: 50px">
			<tr>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 425px; color:green; background-color:green; margin-left:30px; margin-right:30px">
				</td>
				<td>
					<h2 style = "padding-top: 35px; margin-left:16px; margin-right:16px">Tutorial</h2>
				</td>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 425px; color:green; background-color:green; margin-right:30px; margin-left:30px">
				</td>
			</tr>
		</table>
		<table>
			<tr>
				<td>
					<img src="../images/tutorial.png" width="110" height="80" style = "margin-left:6px"><br>
					<h4 style = "padding-right: 50px">English Language</h4><br>
					<a style = "margin-left:-21px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/tutorial.png" width="110" height="80" style = "margin-left:10px"><br>
					<h4 style = "padding-right: 50px">Sinhala Language</h4><br>
					<a style = "margin-left:-20px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/tutorial.png" width="110" height="80" style = "margin-left:-1px"><br>
					<h4 style = "padding-right: 50px">Western Music</h4><br>
					<a style = "margin-left:-29px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/tutorial.png" width="110" height="80" style = "margin-left:60px"><br>
					<h4 style = "padding-right: 50px">Mathematics for Primary Students</h4><br>
					<a style = "margin-left:31px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/tutorial.png" width="110" height="80" style = "margin-left:49px"><br>
					<h4>Science for Secondary Students</h4><br>
					<a style = "margin-left:28px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
			</tr>
		</table>
		<table class = "tuser" style = "padding-top: 50px; padding-bottom: 50px">
			<tr>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 415px; color:green; background-color:green; margin-left:30px; margin-right:30px">
				</td>
				<td>
					<h2 style = "padding-top: 35px; margin-left:16px; margin-right:16px">Lab sheet</h2>
				</td>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 415px; color:green; background-color:green; margin-right:30px; margin-left:30px">
				</td>
			</tr>
		</table>
		<table>
			<tr>
				<td>
					<img src="../images/labsheet.png" width="70" height="80" style = "margin-left:28px"><br>
					<h4 style = "padding-right: 50px">English Language</h4><br>
					<a style = "margin-left:-21px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/labsheet.png" width="70" height="80" style = "margin-left:32px"><br>
					<h4 style = "padding-right: 50px">Sinhala Language</h4><br>
					<a style = "margin-left:-20px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/labsheet.png" width="70" height="80" style = "margin-left:17px"><br>
					<h4 style = "padding-right: 50px">Western Music</h4><br>
					<a style = "margin-left:-29px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/labsheet.png" width="70" height="80" style = "margin-left:72px"><br>
					<h4 style = "padding-right: 50px">Mathematics for Primary Students</h4><br>
					<a style = "margin-left:31px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/labsheet.png" width="70" height="80" style = "margin-left:70px"><br>
					<h4>Science for Secondary Students</h4><br>
					<a style = "margin-left:28px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
			</tr>
		</table>
		<table class = "tuser" style = "padding-top: 50px; padding-bottom: 50px">
			<tr>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 414px; color:green; background-color:green; margin-left:30px; margin-right:30px">
				</td>
				<td>
					<h2 style = "padding-top: 35px">Lecture slide</h2>
				</td>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 414px; color:green; background-color:green; margin-right:30px; margin-left:30px">
				</td>
			</tr>
		</table>
		<table>
			<tr>
				<td>
					<img src="../images/lectureslide.png" width="70" height="80" style = "margin-left:52px">
					<h4 style = "padding-right: 30px">Primary Teaching Course</h4>
					<a style = "margin-left:7px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/lectureslide.png" width="70" height="80" style = "margin-left:60px">
					<h4 style = "padding-right: 30px">Secondary Teaching Course</h4>
					<a style = "margin-left:11px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/lectureslide.png" width="70" height="80" style = "margin-left:56px">
					<h4 style = "padding-right: 30px">Pre-School Teaching Course</h4>
					<a style = "margin-left:13px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/lectureslide.png" width="70" height="80" style = "margin-left:60px">
					<h4 style = "padding-right: 30px">Special Needs Teaching Course</h4>
					<a style = "margin-left:16px" href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
				<td>
					<img src="../images/lectureslide.png" width="70" height="80" style = "margin-left:40px">
					<h4>Music Teaching Course</h4>
					<a href="../images/Edeze.pdf" download rel="noopener noreferrer" target="_blank"><button class = "dbutton" type="button">Download</button></a>
				</td>
			</tr>
		</table>
		<table class = "tuser" style = "padding-top: 50px; padding-bottom: 50px">
			<tr>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 422px; color:green; background-color:green; margin-left:35px; margin-right:35px">
				</td>
				<td>
					<h2 style = "padding-top: 35px">Time table</h2>
				</td>
				<td style = "padding-top: 25px">
					<hr style="height:2px; width: 422px; color:green; background-color:green; margin-right:35px; margin-left:35px">
				</td>
			</tr>
		</table>
		
		<table class = "tuser" style = "padding-top: 30px">
		<tr>
		<td style = "padding-left: 100px">
		<h4 style = "margin-right:100px">Batch &nbsp&nbsp PT-7.1.4 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction1()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown1" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp PT-7.1.5 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction2()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown2" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp PT-7.1.6 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction3()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown3" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp PT-7.1.7 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction4()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown4" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		</td>
		<td>
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp ST-7.1.4 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction5()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown5" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp ST-7.1.5 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction6()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown6" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp ST-7.1.6 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction7()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown7" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp ST-7.1.7 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction8()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown8" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		</td>
		<td>
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp SNT-7.1.4 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction9()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown9" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp SNT-7.1.5 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction10()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown10" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp SNT-7.1.6 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction11()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown11" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		<hr  style = "margin-right:100px">
		<h4  style = "margin-right:100px">Batch &nbsp&nbsp SNT-7.1.7 &nbsp&nbsp
		<div class="dropdown">
		  <button onclick="myFunction12()" class="dropbtn">&#8964;</button>
		  <div id="myDropdown12" class="dropdown-content">
			<a href="../images/Edeze.pdf">1st year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">1st year 2nd semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 1st semester</a><hr>
			<a href="../images/Edeze.pdf">2nd year 2nd semester</a>
		  </div>
		</div></h4>
		</td>
		</tr>
		</table>
		</div>
		
	</div>
	</center>
	
	<script>
	function myFunction1() {
	document.getElementById("myDropdown1").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction2() {
	document.getElementById("myDropdown2").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction3() {
	document.getElementById("myDropdown3").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction4() {
	document.getElementById("myDropdown4").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction5() {
	document.getElementById("myDropdown5").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction6() {
	document.getElementById("myDropdown6").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction7() {
	document.getElementById("myDropdown7").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction8() {
	document.getElementById("myDropdown8").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction9() {
	document.getElementById("myDropdown9").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction10() {
	document.getElementById("myDropdown10").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction11() {
	document.getElementById("myDropdown11").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	function myFunction12() {
	document.getElementById("myDropdown12").classList.toggle("show");
	}


	window.onclick = function(event) {
		if (!event.target.matches('.dropbtn')) {
			var dropdowns = document.getElementsByClassName("dropdown-content");
			var i;
			for (i = 0; i < dropdowns.length; i++) {
				var openDropdown = dropdowns[i];
				if (openDropdown.classList.contains('show')) {
					openDropdown.classList.remove('show');
				}
			}
		}
	}
	</script>

	<!-- Footer -->
	
	<div class="coldiv">

				
				<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
					<center>
					<table class="font">
						<tr style="font-size: larger; color: #2e7d4d;">
							<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
							<th style="width: 30%;">Useful Links</th>
							<th style="width: 30%;">Our Social Networks</th>
						</tr>

						<tr>
							<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
						

							
							<td style="padding-left: 170px;" >
								<a href="home_page.php" class="link">Home</a><br>
								<a href="Courses.php" class="link">Courses</a><br>
								<a href="Download.php" class="link"> Download</a><br>
								<a href="announcement.php" class="link"> Announcements</a><br>
								<a href="enroll.php" class="link">Enroll</a><br>
								<a href="feedback.php" class="link">Feedbacks</a><br>
								<a href="Account.php" class="link">Account</a><br>
								<a href="staffPage.php" class="link">Staff</a><br>
								<a href="login.php" class="link">Log in</a><br>
								<a href="register.php" class="link">Register</a>
							</td>

							<td style="padding-left: 110px; padding-top: 20px;">
								<div class="SocialLogos">
									<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
									<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
									<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
									<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
									 
								</div>
							</td>


						</tr>

					</table>
					</center>
				
				</div>
					<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 - edeze - Online Teacher Training School - All Right Reserved</h3></center>
			</div>

	<!-- End of the Footer  -->
	
</body>

</html>