<!DOCTYPE html>
<html>
<head>
	<title>Homepage | Edeze</title>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">
	<link rel="stylesheet" type="text/css" href="../css/homepage.css">
	

</head>
<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">

		</center>
		
		<!-- Navigation Bar --> 
			<ul style="font-family: Arial, Helvetica, sans-serif;">
				
			  	<li><a class="active" href="home_page.php">Home</a></li>
			  	<li><a href="Courses.php">Courses</a></li>
			  	<li><a href="Download.php">Download</a></li>
			  	<li><a href="announcement.php">Announcements</a></li>	
			  	<li><a href="enroll.php">Enroll</a></li>
			  	<li><a href="feedback.php">Feedbacks</a></li>
			  	<li><a href="Account.php">Account</a></li>
			  	<li><a href="staffPage.php">Staff</a></li>
			  	<li><a href="loginPage.php">Log in</a></li>
			  	<li><a href="register.php" >Register now</a></li>
			</ul>
	</div>

	<!-- end of the header --> 

	
 	<!-- slideshow begins -->
	<div class="w3-content w3-section" style="max-width:100%; height: 1000px; padding-top: 30px;">
		<img class="mySlides1" src="../images/homepage/6.jpg" style="width:100%">
	  	<img class="mySlides1" src="../images/homepage/2.jpeg" style="width:100%">
	  	<img class="mySlides1" src="../images/homepage/4.jpeg" style="width:100%">
	  	<img class="mySlides1" src="../images/homepage/5.jpeg" style="width:100%">
	  
	</div>

	<script>
		var myIndex = 0;
		carousel();

		function carousel() {
		  	var i;
		  	var x = document.getElementsByClassName("mySlides1");
		  	for (i = 0; i < x.length; i++) {
		    	x[i].style.display = "none";  
		  	}
		  	myIndex++;
		  	if (myIndex > x.length) {myIndex = 1}    
		  	x[myIndex-1].style.display = "block";  
		  	setTimeout(carousel, 2500); // Change image every 2 seconds
		}
	</script>
	<!-- end of slideshow -->


	<br><br><br>
	



	<!-- description -->
	<center>
	<div style="background-color: #f5f2f0; padding-top: 50px; padding-bottom: 50px; margin-top: 80px; width: 90%;">
		<p style="font-size: medium;" >
			The Edeze Teacher Training College offers World Class Teacher Training Programmes for those who aspire to graduate from a prestigious institution which is a symbol of national pride and international acclaim. The tailor-made job oriented courses provide endless job opportunities locally and internationally. The comprehensive training is the key to an esteemed vocation, centered on the valuable lives of children.<br><br>

			The Edeze Teacher Training College based in Colombo- Malabe are pioneers in English medium teacher training since 2012, having produced scores of qualified teachers who have continued with us or used the knowledge gained to pursue their career aspirations in overseas.
		</p>

		<table  style="width: 100%; font-size: larger;">
			<tr>
				<th><div><b>Annual Intakes</b><br><br><img src="../images/homepage/intake.jpg" width="10%"><br><br> Two Intakes: <br> Janurary and May</div></th>
				<th><b>Registered Programmes</b><br><br><img src="../images/homepage/dip.png" width="10%"><br><br>All programmes are registered <br>under <br>Tertiary and Vocational Education Commission ,Sri Lanka</th>
			</tr>

			
		</table>
	</div>
	</center><br>
	<!-- end of description -->


	<!-- Feedbacks  --> 

	<center>
	<div style="max-width:1200px; background-color: #f5f2f0; padding-bottom: 30px; margin-top: 80px; margin-bottom: 80px;">
		<h1 style="padding-top: 20px;">Student Feedbacks</h1>

	  <div class="mySlides">
	    <img src="../images/homepage/st1.jpg" class="ss" style="width: 20%;">
	    <p> The Teaching Course was very valuable to me as well as I'm sure it was valuable to others too. Edeze Taining College is a great educational center which is conducted through online platform without any difficulty and interestingly. </p>
	  </div>

	 <div class="mySlides">
	    <img src="../images/homepage/st2.png" class="ss" style="width: 20%;">
	    <p>I was not sure about my future when I first join Edeze. But after 3 years, Edeze made me a teacher with so much of motivation and courage with determination. Today I'm a teacher at xx school. Though it is conducted online, it is really worthful and they conduct the lectures very interestingly and friendly manner. This saves time also and we had plenty to study for exams. I highly recommend Edeze Online Teacher Training School for everyone who wish to become a teacher.</p>
	  </div>

	  <div class="mySlides">
	    <img src="../images/homepage/st3.jpg" class="ss"  style="width: 20%;">
	    <p>I highly recommend Edeze Teaching School. It gave me opportunty to become a successful teacher. It was very easy for me to join as a teacher to reputed international school in Sri Lanka since Edeze is approved by Teritary and Vocational Commision of Sri Lanka.</p>
	  </div>

	  <button class="w3-button w3-black w3-display-left" onclick="plusDivs(-1)">&#10094;</button>
  	<button class="w3-button w3-black w3-display-right" onclick="plusDivs(1)">&#10095;</button>
	</div>
	
	<script>
		var slideIndex = 1;
		showDivs(slideIndex);

		function plusDivs(n) {
		  showDivs(slideIndex += n);
		}

		function showDivs(n) {
		  var i;
		  var x = document.getElementsByClassName("mySlides");
		  if (n > x.length) {slideIndex = 1}
		  if (n < 1) {slideIndex = x.length}
		  for (i = 0; i < x.length; i++) {
		    x[i].style.display = "none";  
		  }
		  x[slideIndex-1].style.display = "block";  
		}

	</script>


	<!-- End of Feedbacks --> 

	<center><div style="max-width:1200px; background-color: #f5f2f0; background-image: ../images/register/b.jpg; padding-bottom: 30px; margin-top: 80px; margin-bottom: 80px;">
		<h1 style="color: red; padding-top: 40px;">Register Now !!!</h1>
		<p style="font-size: 20px;">Click here to <a href="register.php" style="color: #3d8f5d;">Register</a>.</p>
	</div></center>


	<!-- Footer -->
	
	<div class="coldiv">

				
				<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
					<table class="font">
						<tr style="font-size: larger; color: #2e7d4d;">
							<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
							<th style="width: 30%;">Useful Links</th>
							<th style="width: 30%;">Our Social Networks</th>
						</tr>

						<tr>
							<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
						

							
							<td style="padding-left: 170px;" >
								<a href="home_page.php" class="link">Home</a><br>
								<a href="Courses.php" class="link">Courses</a><br>
								<a href="Download.php" class="link"> Download</a><br>
								<a href="announcement.php" class="link"> Announcements</a><br>
								<a href="enroll.php" class="link">Enroll</a><br>
								<a href="feedback.php" class="link">Feedbacks</a><br>
								<a href="Account.php" class="link">Account</a><br>
								<a href="staffPage.php" class="link">Staff</a><br>
								<a href="login.php" class="link">Log in</a><br>
								<a href="register.php" class="link">Register</a>
							</td>

							<td style="padding-left: 110px; padding-top: 20px;">
								<div class="SocialLogos">
									<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
									<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
									<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
									<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
									 
								</div>
							</td>


						</tr>

					</table>
				
				</div>
					<h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 -edeze - Online Teacher Training School - All Right Reserved</h3>
			</div>

	<!-- End of the Footer  -->


</body>
</html>