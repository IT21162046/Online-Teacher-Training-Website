<?php
	session_start();
	$_SESSION["adminId"] = "1";
	//$conn = mysqli_connect("localhost", "root", "", "userdb") or die("Connection Error: " . mysqli_error($conn));
	
	$dbhost = '127.0.0.1';
    $dbuser = 'root';
    $dbpass = '';
    $dbname = 'iwt_assignment';

    // // $conn = mysqli_connect([host], [username], [password], [database name]);

    // $conn = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
    
    $conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);

    // // if the db connection fails, dispaly an error message and exit
    if(!$conn){
        die('could not connect:'. mysqli_error($conn));
    }
    // // //select the database
    mysqli_select_db($conn,$dbname);

	if (count($_POST) > 0) 
		{
			$result = mysqli_query($conn, "SELECT *from adminlogin WHERE adminId='" . $_SESSION["adminId"] . "'");
			$row = mysqli_fetch_array($result);
				if ($_POST["currentPassword"] == $row["adminPassword"]) 
				{
					mysqli_query($conn, "UPDATE adminlogin set adminPassword='" . $_POST["newPassword"] . "' WHERE adminId='" . $_SESSION["adminId"] . "'");
					$message = "Password Changed";
				} 
				else
					$message = "Current Password is not correct";
				}
?>