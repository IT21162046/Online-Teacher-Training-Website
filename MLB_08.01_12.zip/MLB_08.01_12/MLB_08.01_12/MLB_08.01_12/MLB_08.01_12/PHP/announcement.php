<?php
	include "register_config.php";

	if (isset($_REQUEST["del"])) {
		$id=$_REQUEST["id"];
		$sql = " DELETE FROM announcements WHERE id='$id' "; //delete query

		//Execution and testing
	  	$result = $conn->query($sql);
	  	if ($result == TRUE) {
	    	header('Location: announcement.php');
	  	}
	  	else
	  	{
	  	  echo "Error:". $sql . "<br>". $conn->error;
	 	  }
	}

	if (isset($_REQUEST["update"])) {
		$id=$_REQUEST["id"];
		$announcement=$_REQUEST["announcement"];
		$sql = " UPDATE announcements SET announcement='$announcement' WHERE id='$id' "; // update query

		//Execution and testing
	  	$result = $conn->query($sql);
	  	if ($result == TRUE) {
	    	header('Location: announcement.php');
	  	}
	  	else
	  	{
	  	  echo "Error:". $sql . "<br>". $conn->error;
	 	}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>

	<link rel="stylesheet" type="text/css" href="../css/header.css">
	<link rel="stylesheet" type="text/css" href="../css/general.css">

</head>
<body>

	<!-- Header --> 
	<div >

		<center>
		<img src="../images/homepage/logo121.png" style="padding-right: 1600px; padding-top: 10px; padding-bottom: 10px;">
		</center>
		
		<!-- Navigation Bar --> 
		<ul style="font-family: Arial, Helvetica, sans-serif;">
			
			<li><a href="home_page.php">Home</a></li>
			<li><a href="Courses.php">Courses</a></li>
			<li><a href="Download.php">Download</a></li>
			<li><a class="active" href="announcement.php">Announcements</a></li>	
			<li><a href="enroll.php">Enroll</a></li>
			<li><a href="feedback.php">Feedbacks</a></li>
			<li><a href="Account.php">Account</a></li>
			<li><a href="staffPage.php">Staff</a></li>
			<li><a href="loginPage.php">Log in</a></li>
			<li><a href="register.php">Register now</a></li>
		</ul>
	</div>

	<!-- end of the header --> 
	<br>

	<center><h1>Announcements</h1>
	<img src="../images/announcements/logo.png" style="width: 5%;">
	</center>
	<br>


	<?php 
	$count=1;
	$sql = "SELECT * FROM announcements ORDER BY id DESC";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
	while($row = $result->fetch_assoc()) {
	?>

	<center>
	<div style="width:70%; margin-bottom:10px; border:2px solid black; padding:10px 10px; text-align:left; background-color:#f5f2f0;">
		<p style="color: #6a6e6b;"><b>Announcement <?php echo $count; ?></b> :<br><br> <font style="color:black; font-size: 20px;"><?php echo $row["announcement"]; ?></font></p><br>
		<a href="?id=<?php echo $row["id"]; ?>&del=1">Delete</a>
		<a href="?id=<?php echo $row["id"]; ?>&edit=1">Edit</a>
	</div>

	<!-- update -->
	<?php if(isset($_REQUEST["edit"]) AND $_REQUEST["id"]==$row["id"]) {?>
		<div style="margin-bottom:50px;">
			<form method="" action="">
				<textarea placeholder="Edit your announcement" name="announcement" style="width: 500px; height: 200px; font-size: 17px;"><?php echo $row["announcement"]; ?></textarea>
				<br>
				<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">
				<input type="submit" name="update" style="background-color: #3d8f5d;">
			</form>
		</div>
	<?php } ?>
	</center>
	<?php $count++; }	} else {echo "<center><b>No announcements</b></center>";}?>

	<hr>

	<center>

	<div>
		<form method="POST" action="announcement_insert.php">
			<textarea placeholder="Publish a new announcement" name="announcement" style="width: 500px; height: 200px; font-size: 17px; padding-left:10px;"></textarea><br>
			<button type="submit" value="submit" onclick="myfunction()" style="background-color: #3d8f5d;">
				<b>Submit</b></button>
			<!-- confirm submission -->
			<script type="text/javascript">
				function myfunction(){
					alert("Are you sure you want to submit the announcement!");
				}
			</script>
		</form>
	</div>
	</center>



	<!-- Footer -->
	
	<div class="coldiv">

				
		<div style="background-color: #f7fafa; padding-bottom: 80px; padding-top: 80px;">
			<table class="font">
				<tr style="font-size: larger; color: #2e7d4d;">
					<th style="width: 30%;margin: 0;"><img src="../images/homepage/logo121.png" style="width: 50%;"></th>
					<th style="width: 30%;">Useful Links</th>
					<th style="width: 30%;">Our Social Networks</th>
				</tr>

				<tr>
					<td style="padding-left: 150px;padding-bottom: 10px;">No.205/A,<br> New Kandy Road,<br>Malabe 10115 <br> Sri Lanka<br><br> <b>Phone: </b> 0715 468 230<br><b> Email: </b> edeze@gmail.com </td>
				

					
					<td style="padding-left: 170px;" >
						<a href="home_page.php" class="link">Home</a><br>
						<a href="Courses.php" class="link">Courses</a><br>
						<a href="Download.php" class="link"> Download</a><br>
						<a href="announcement.php" class="link"> Announcements</a><br>
						<a href="enroll.php" class="link">Enroll</a><br>
						<a href="feedback.php" class="link">Feedbacks</a><br>
						<a href="Account.php" class="link">Account</a><br>
						<a href="staffPage.php" class="link">Staff</a><br>
						<a href="loginPage.php" class="link">Log in</a><br>
						<a href="register.php" class="link">Register</a>
					</td>

					<td style="padding-left: 110px; padding-top: 20px;">
						<div class="SocialLogos">
							<p style="padding-bottom: 10px;"> Find Us on Social Media</p><br>
							<a href="http://facebook.com" style="padding-left: 30px;" ><img src="../images/homepage/FbLogo.png" alt="Facebook" style="padding-bottom: 100px;"></a> 
							<a href="http://instagram.com" ><img src="../images/homepage/InstaLogo.png" alt="Instagram" style="padding-bottom: 100px;"></a> 
							<a href="http://twitter.com" ><img src="../images/homepage/TwitterLogo.png" alt="Twitter" style="padding-bottom: 100px;"></a>
						</div>
					</td>
				</tr>
			</table>
		</div>
		<center><h3 style="padding-top: 10px; padding-bottom: 25px; color: black; font-family: Arial, Helvetica, sans-serif;">Copyright &#169; 2022 -edeze - Online Teacher Training School - All Right Reserved</h3></center>
	</div>

	<!-- End of the Footer  -->
</body>
</html>