<?php require_once('connection.php'); 

	if(isset($_GET['deleteid'])){
		$admin_id=$_GET['deleteid'];
		
		$sql="delete from admin where admin_id='$admin_id'";
		$result=mysqli_query($connection,$sql);
		if($result){
			//echo "Deleted successfull";
			header('location:Account_display.php');
		}else{
			die('Database connection failed' . mysqli_connect_error());
		}
	}
	
	
	if(isset($_GET['deleteid'])){
		$cc_id=$_GET['deleteid'];
		
		$sql="delete from course_coordinator where cc_id='$cc_id'";
		$result=mysqli_query($connection,$sql);
		if($result){
			//echo "Deleted successfull";
			header('location:Account_display.php');
		}else{
			die('Database connection failed' . mysqli_connect_error());
		}
	}
	
	
	if(isset($_GET['deleteid'])){
		$lec_id=$_GET['deleteid'];
		
		$sql="delete from lecturer where lec_id='$lec_id'";
		$result=mysqli_query($connection,$sql);
		if($result){
			//echo "Deleted successfull";
			header('location:Account_display.php');
		}else{
			die('Database connection failed' . mysqli_connect_error());
		}
	}
	
	
	if(isset($_GET['deleteid'])){
		$st_id=$_GET['deleteid'];
		
		$sql="delete from student where st_id='$st_id'";
		$result=mysqli_query($connection,$sql);
		if($result){
			//echo "Deleted successfull";
			header('location:Account_display.php');
		}else{
			die('Database connection failed' . mysqli_connect_error());
		}
	}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Delete user details</title>
</head>
<body>
</body>
</html>
<?php mysqli_close($connection); ?>